This is a cut-down version of the TCLAP library
This library can be found here: http://tclap.sourceforge.net/