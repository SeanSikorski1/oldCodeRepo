#ifndef GAMES_CHESS_AI_HPP
#define GAMES_CHESS_AI_HPP

#include "impl/chess.hpp"
#include "game.hpp"
#include "game_object.hpp"
#include "move.hpp"
#include "piece.hpp"
#include "player.hpp"

#include "../../joueur/src/base_ai.hpp"
#include "../../joueur/src/attr_wrapper.hpp"

// <<-- Creer-Merge: includes -->> - Code you add between this comment and the end comment will be preserved between Creer re-runs.
// You can add additional #includes here
// <<-- /Creer-Merge: includes -->>

namespace cpp_client
{

namespace chess
{

/// <summary>
/// This is the header file for building your Chess AI
/// </summary>

class historyT
{
public:
    char board[8][8];
    unsigned rank;
//functions
    historyT(const char state[8][8]);
    bool isMatch(const char state[8][8]);
};//historyT

class State
{
public:
    char board[8][8];
    bool riskState[8][8];
    bool occupancy[8][8];
//functions
    State();
    State(const char state[8][8], std::string color);
    
    
    
    
};//State

class moveList
{ 
public:
    //post move state
    State state;
    //move information
    int rank;
    std::string file;
    int moveRank;
    std::string moveFile;
    //score
    int score;
    int priority;
    //current team
    std::string color;

    std::vector<moveList> children;
//functions
    moveList();
    moveList(const char board[8][8], std::string team);
    moveList(moveList item, int y, std::string x, int moveY, std::string moveX);
    moveList(int y, std::string x, int moveY, std::string moveX, int amount, std::string team, const char board[8][8]);
};//moveList

bool isQuiesent(State state, std::string color);
void organizeList(std::vector<historyT> historyTable, std::vector<moveList> &movelist);
moveList minimax(std::vector<moveList> &movelist, std::vector<historyT> &historyTable, int qDepth, int depth, int max, int min);
int findMax(moveList &move, std::vector<historyT> &historyTable, int qDepth, int depth, int max, int min);
int findMin(moveList &move, std::vector<historyT> &historyTable, int qDepth, int depth, int max, int min);
void printBoard(const char board[8][8]);
bool isOccupied(int x, int y, std::string color, const char state[8][8]);
void occupancyTest(bool (&house)[8][8],std::string color, const char state[8][8]);
void bishopRisk(bool (&risk)[8][8], const char state[8][8], int x, int y, std::string color);
void rookRisk(bool (&risk)[8][8], const char state[8][8], int x, int y, std::string color);
void genRisk(bool (&risk)[8][8], const char state[8][8], std::string color);
std::vector<moveList> pawnMoves(int x, int y, moveList curState);
std::vector<moveList> knightMoves(int x, int y, moveList curState);
std::vector<moveList> bishopMoves(int x, int y, moveList curState);
std::vector<moveList> queenMoves(int x, int y, moveList curState);
std::vector<moveList> kingMoves(int x, int y, moveList curState);
std::vector<moveList> rookMoves(int x, int y, moveList curState);
std::vector<moveList> createMoves(moveList curState);
class AI : public Base_ai
{
public:
    /// <summary>
    /// This is a reference to the Game object itself, it contains all the information about the current game
    /// </summary>
    Game game;

    /// <summary>
    /// This is a pointer to your AI's player. This AI class is not a player, but it should command this Player.
    /// </summary>
    Player player;

    //<<-- Creer-Merge: class variables -->> - Code you add between this comment and the end comment will be preserved between Creer re-runs.
    // You can add additional class variables here.
    //<<-- /Creer-Merge: class variables -->>

    /// <summary>
    /// This returns your AI's name to the game server.
    /// Replace the string name.
    /// </summary>
    /// <returns>The name of your AI.</returns>
    virtual std::string get_name() const override;

    /// <summary>
    /// This is automatically called when the game first starts, once the game objects are created
    /// </summary>
    virtual void start() override;

    /// <summary>
    /// This is automatically called when the game ends.
    /// </summary>
    /// <param name="won">true if you won, false otherwise</param>
    /// <param name="reason">An explanation for why you either won or lost</param>
    virtual void ended(bool won, const std::string& reason) override;

    /// <summary>
    /// This is automatically called the game (or anything in it) updates
    /// </summary>
    virtual void game_updated() override;

    /// <summary>
    /// This is called every time it is this AI.player's turn.
    /// </summary>
    /// <returns>Represents if you want to end your turn. True means end your turn, False means to keep your turn going and re-call this function.</returns>
    bool run_turn();

    // <<-- Creer-Merge: methods -->> - Code you add between this comment and the end comment will be preserved between Creer re-runs.
    // You can add additional methods here.
    // <<-- /Creer-Merge: methods -->>

    void printMove(const chess::Piece piece, const moveList move);
    void printMoves(const chess::Piece piece, const std::vector<moveList> movelist);
    void genState(char (&state)[8][8]);

    bool futureCheck(const bool risk[8][8], const char state[8][8], std::string color);

    
    
    
    // ####################
    // Don't edit these!
    // ####################
    /// \cond FALSE
    virtual std::string invoke_by_name(const std::string& name,
                                       const std::unordered_map<std::string, Any>& args) override;
    virtual void set_game(Base_game* ptr) override;
    virtual void set_player(std::shared_ptr<Base_object> obj) override;
    virtual void print_win_loss_info() override;
    /// \endcond
    // ####################
    // Don't edit these!
    // ####################

};

void test(const char board[8][8], bool (&house)[8][8], bool (&risk)[8][8], std::string color);

} // CHESS

} // cpp_client

#endif // GAMES_CHESS_AI_HPP
