###########################################################
#Sean Sikorski                                  oct 6, 2018
#titanicStatGen.py                              compSci3001
###########################################################
#Predicts if a set of people survived the titanic given
#  another set to create a predictive model off of
###########################################################
# python titanicStatGen.py
###########################################################
#imports
import pandas as pd 
import numpy as np
import random as rand

#df = data frame 

#helps band together fare groups (explained further in prepareSet())
#  created specifically for mapping to a df so item represents 
#  a specific attribute from a sequence
def fareBand(item):
    if item < 7.91:
        return 0
    elif item >= 7.91 and item < 14.454:
        return 1
    elif item >= 14.454 and item < 31.0:
        return 2
    elif item >= 31.0 and item <= 512.329:
        return 3

#sets up a given df to be cleaned and better used for gethering 
#  correlations from them. 
#  (removes unneeded attributes and replaces NaN values etc.)
def prepareSet(df):
    temp_df = df

    #remove unneaded attributes
    temp_df = temp_df.drop(['Cabin','Ticket', 'Name', 'SibSp', 'Parch'], axis=1)

    #replace NaN values in Embarked and Fare with the most frequent of their respective sets
    temp_df['Embarked'] = temp_df['Embarked'].replace(np.nan, temp_df['Embarked'].mode()[0], regex=True)
    temp_df['Fare'] = temp_df['Fare'].replace(np.nan, temp_df['Fare'].mode()[0], regex=True)

    #Converting Fare to Ordinal values as described below
    #Ordinal value : Band : survival chance
    # 0 : (-0.001, 7.91) : 0.197309
    # 1 : (7.91, 14.454) : 0.303571
    # 2 : (14.454, 31.0) : 0.454955
    # 3 : (31.0, 512.329) : 0.581081
    temp_df['Fare'] = temp_df['Fare'].map(fareBand)

    #fill in blank Ages with standard deviation of the mean age
    ageStd = int(temp_df['Age'].std())
    ageMean = int(temp_df['Age'].mean())

    temp_df['Age'] = temp_df['Age'].replace(np.nan, rand.randint(ageMean - ageStd, ageMean + ageStd))

    #replace female with 1 and male with 0 to find 
    #  correlations easily
    temp_df = temp_df.replace('female', 1)
    temp_df = temp_df.replace('male', 0)
    
    return temp_df

#I'm honestly not sure how to work with raw correlation values
#  when it deals with more than 2 values so I use this funciton
#  to break each attribute into set percentiles of each attribute 
#  value.
#  takes in a df you want searched, 
#  the attribute you want and 
#  the value from that attribute you want stacked up against survival
def getSingleCorr(df, attribute, value):
    temp1_df = df.loc[df[attribute] == value]
    temp2_df = temp1_df.loc[temp1_df['Survived'] == 1]
    return len(temp2_df.index) / len(temp1_df.index)

#the meat and potatoes of this program.
#  this grabs each helpful attribute and grabs the percentile
#  chance that a person with this attribute will survive
#  then takes the average of all the percentages to give 
#  you a grand percentile chance of survival.
def main():
    #grabing data and creating tables
    train_df = pd.read_csv('input/train.csv')
    test_df = pd.read_csv('input/test.csv')
    
    #Given percentiles of fare to survival chance
    fare0 = .197309
    fare1 = .303571
    fare2 = .454955
    fare3 = .581081

    #clean up and prepare the data set to get survival percentiles
    #  explained in depth at prepareSet funciton declaration
    final_df = prepareSet(train_df)

    #Banding Age groups and their respective correlation 
    #  child = 0-4
    #  kid = 5-12
    #  young = 13-25
    #  Adult = 26-40
    #  Old = 40 and up
    temp_df = train_df.loc[train_df['Age'] <= 4]
    childCorr = (temp_df['Age'].corr(temp_df['Survived']) + 1) / 2

    temp_df = train_df.loc[train_df['Age'].between(5,12)] 
    kidCorr = (temp_df['Age'].corr(temp_df['Survived']) + 1) / 2

    temp_df = train_df.loc[train_df['Age'].between(13,25)]
    youngCorr = (temp_df['Age'].corr(temp_df['Survived']) + 1) / 2

    temp_df = train_df.loc[train_df['Age'].between(26,40)]
    adultCorr = (temp_df['Age'].corr(temp_df['Survived']) + 1) / 2

    temp_df = train_df.loc[train_df['Age'] > 40]
    oldCorr = (temp_df['Age'].corr(temp_df['Survived']) + 1) / 2

    #grabing correlations for pclass, gender and embarked to survival
    class1 = getSingleCorr(final_df, 'Pclass', 1)
    class2 = getSingleCorr(final_df, 'Pclass', 2)
    class3 = getSingleCorr(final_df, 'Pclass', 3)

    gendCorr = (final_df['Sex'].corr(final_df['Survived']) + 1) / 2

    embarkedS = getSingleCorr(final_df, 'Embarked', 'S')
    embarkedC = getSingleCorr(final_df, 'Embarked', 'C')
    embarkedQ = getSingleCorr(final_df, 'Embarked', 'Q')

    ##################################################################
    # Now that we have all the percentiles that we could ever need we
    #   can start preparing the test set to predict who survived and 
    #   who didn't.
    ##################################################################
    #preparing test set 
    test_df = prepareSet(test_df)

    #preparing output file
    outputFile = open('Survival.csv', 'w+')
    outputFile.write('PassengerId,Survived\n')

    #loops through each row of the test df
    #  from there it adds up the percentile chance of survival
    #  then uses it to predict if the person survived
    #**This loop is where you would add weight to certain percentiles
    #  if you wanted**
    for index, row in test_df.iterrows():
        totalPerc = 0

        #Pclass/survival percent added
        if row['Pclass'] == 1:
            totalPerc = totalPerc + class1
        elif row['Pclass'] == 2:
            totalPerc = totalPerc + class2
        else:
            totalPerc = totalPerc + class3

        #Gender/survival percent added
        if row['Sex'] == 1:
            totalPerc = totalPerc + gendCorr
        else:
            totalPerc = totalPerc + (1 - gendCorr)

        #Fare/survival percent added
        if row['Fare'] == 0:
            totalPerc = totalPerc + fare0
        elif row['Fare'] == 1:
            totalPerc = totalPerc + fare1
        elif row['Fare'] == 2:
            totalPerc = totalPerc + fare2
        else:
            totalPerc = totalPerc + fare3
        
        #Embarkment-location/surival percent added
        if row['Embarked'] == 'S':
            totalPerc = totalPerc + embarkedS
        elif row['Embarked'] == 'C':
            totalPerc = totalPerc + embarkedC
        else:
            totalPerc = totalPerc + embarkedQ

        #age/survival percent added
        if row['Age'] <= 4:
            totalPerc = totalPerc + childCorr
        elif row['Age'] > 4 and row['Age'] <= 12:
            totalPerc = totalPerc + kidCorr
        elif row['Age'] > 12 and row['Age'] <= 25:
            totalPerc = totalPerc + youngCorr
        elif row['Age'] > 25 and row['Age'] <= 40:
            totalPerc = totalPerc + adultCorr
        else:
            totalPerc = totalPerc + oldCorr

        #takes the average off all the percents 
        totalPerc = (totalPerc / 5) * 100

        #prepare output message
        outputMessage = str(row['PassengerId']) + ','
        
        #if this randChance is less than the percentile then 
        #  they survived. Otherwise they are noted as dead
        randChance = rand.randint(0, 100)
        
        if randChance <= totalPerc:
            outputMessage = outputMessage + '1\n'
        else:
            outputMessage = outputMessage + '0\n'
        
        #output the result to our created csv file
        outputFile.write(outputMessage)
        



if __name__ == '__main__':
    main()