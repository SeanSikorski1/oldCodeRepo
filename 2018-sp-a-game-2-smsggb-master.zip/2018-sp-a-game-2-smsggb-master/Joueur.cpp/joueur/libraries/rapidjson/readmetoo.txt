This is a cut-down version of the rapidjson library.
This library can be found here: https://github.com/miloyip/rapidjson