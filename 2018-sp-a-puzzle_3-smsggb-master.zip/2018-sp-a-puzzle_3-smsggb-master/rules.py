#############################################################################
#Sean Sikorski                                               completed:2/2/18
#rules.py                                                         compsci5400
#############################################################################
#This class will hold all the specific rules that the given puzzle must 
#abide by including:
# quota - the score to reach
# moves - the max amount of moves the node can have
# devTypes - the max amount of different "jewels" that can be in the puzzle
# w - width of the game
# h - hight of the game (pool not included)
# poolH - hight of the pool above the puzzle
# special - special rules? doesn't really get used but keeping it here for 
#           future use

class rules:

    def __init__(self, quota, moves, devTypes, w, h, poolH, special):
        self.quota = quota
        self.moves = moves
        self.devTypes = devTypes
        self.w = w
        self.h = h
        self.poolH = poolH
        self.special = special
