#############################################################################
#Sean Sikorski                                               completed:2/2/18
#main.py                                                          compsci5400
#############################################################################
#imports
from datetime import datetime
import argparse #allows main to read commandline arguments
import mainfunc as func
#other imports are made inside of mainfunc
#start the timer
startTime = datetime.now()
#############################################################################
#read designated file to construct the puzzle
#also creates the solution file for the given puzzle: ex puzzle 1 would be
#"solution1.txt"

#allows my program to choose the input file from the command line
parser = argparse.ArgumentParser()
parser.add_argument("input", help="choose the input file to be solved (1-4)", type=int)
args = parser.parse_args()

f = open("input"+str(args.input)+".txt")#maker file with rules and starting puzzle
f2 = open("solution"+str(args.input)+".txt", "w+")#creates solution file for the puzzle

qouta = int(f.readline())
moves = int(f.readline())
devTypes = int(f.readline())
w = int(f.readline())
h = int(f.readline())
poolH = int(f.readline())
special = int(f.readline())

h = h - poolH #I messed up and calculated h as being seperate from the pool
              #   this fixes it without needing to change all of my code

#############################################################################
#construct the puzzle with the given values

pRules = func.rules.rules(qouta,moves,devTypes,w,h,poolH,special)#constraints for the game
frontier = []#list of nodes
puzzle = []#2d list of ints that will be our puzzle
traversed = []#list of traversed puzzles 

#constructs the grid part of the puzzle and ensures that they are read as ints
puzzle = [(int(s) for s in f.readline().split(' ')) for y in range(pRules.poolH + pRules.h)]
for y in range(pRules.poolH + pRules.h):
    puzzle = [list(map(int, x)) for x in puzzle]

f.close()#closes the input file
#############################################################################
#create the first frontier with the given puzzle

frontier.extend(func.formFirstFrontier(puzzle, pRules, traversed))

#############################################################################
#sort based on the heuristic
#for greedy it would be MIN(quota - score) so I took the equivalent MAX(score)
#  to save a bit of time and space calculating it.
frontier = sorted(frontier, key=lambda node: node.score, reverse=True)

#############################################################################
#look for a goal within the first state then check its leafs etc extending 
#   the frontier until frontier reaches 0 or goal is found

goal = False #trying to make a do while in python
while(len(frontier) != 0 and goal == False):
    goal = func.isGoal(pRules, frontier[0]) #checks if it is a goal
    if(goal): #if it is then print the path
        func.printPath(frontier[0], f2, args)
    #if it is not the goal and there are still steps available to it we gather
    #   more leafs for the frontier, sort it in accordance to the heuristic
    #   and pop the front
    if not goal and not func.overStep(pRules, frontier[0]): 
        frontier.extend(func.formNextFrontier(frontier[0].state, pRules, frontier[0], traversed))
        frontier = sorted(frontier, key=lambda node: node.score, reverse=True)
    del frontier[0]

#############################################################################
if(goal):
    f2.write("goal found")
else:
    f2.write("goal not found")

#print total time elapsed
f2.write("\n"+str(datetime.now() - startTime))
