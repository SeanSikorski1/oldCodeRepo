###########################################################
#Sean Sikorski                                sept 16, 2018
#crawler.py                                     compSci3001
###########################################################
#Crawls through the mst domain saving files to pages dir
#   for the specified amount of pages or a default of ten
#   not including the main mst website
###########################################################
# python crawler.py --MC <max crawl int>
###########################################################
#imports
import hashlib, re, argparse, requests
from bs4 import BeautifulSoup
#initialize regex command for finding mst sites
p = re.compile('http:[\S^@]*.mst.edu\S*')

def main():
    #create a optional argument to set the max number of crawled sites
    parser = argparse.ArgumentParser(description='set default crawl size (int)')
    parser.add_argument('--MC', type= int, default= 10)
    args = parser.parse_args()

    #start a list of travelable sites based on mst.edu
    hrefs = crawl('http://www.mst.edu/')
    #initialize the list of sites already crawled through
    crawled = []
    
    #loop through crawling through the specified number of sites
    #this doesn't account for hitting end of list yet so for now 
    #  we assume specified number is less than sites found
    i = 0
    while i < args.MC:
        if hrefs[i] not in crawled:
            crawled.append(hrefs[i])
            hrefs = hrefs + crawl(hrefs[i]) 
            i += 1

        

def crawl(href):
    #find and download page here
    page = requests.get(href)
    soup = BeautifulSoup(page.content, 'html.parser')

    #do stuff with page here
    filename = 'pages/' + hashlib.md5(href.encode()).hexdigest()+'.html'
    file = open(filename, 'w+')
    file.write(str(soup.prettify))
    file.close

    #grab all hrefs from given page to send back to list of sites
    # to be traveled
    temp = []
    for a in soup.find_all('a', href=True):
        if p.match(a['href']):
            temp.append(a['href'])
    return temp


if __name__ == '__main__':
    main()