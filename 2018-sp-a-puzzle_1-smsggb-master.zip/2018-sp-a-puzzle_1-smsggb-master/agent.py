#############################################################################
#Sean Sikorski                                               completed:2/2/18
#agent.py                                                         compsci5400
#############################################################################
#the node class will help keep track of and search our given puzzle and be
#"nodes" in our search tree. This class includes:
# x1 - part1 of an action this is the initial x pos of "jewel" to be swapped
# y1 - the initial y pos of "jewel" to be swapped
# x2 - the x swap position of the "jewel"
# y2 - the y swap position of the "jewel"
# parent - in order to create and return a path each node must beable to 
#          designate who its parent is to recall actions and print them
# score - total score that has been accumulated so far
# steps - total number of steps taken up to this point
# state - the nodes individual copy of their parents puzzle to test further
#         actions on and create child nodes from 

class node:

    def __init__(self, x1, y1, x2, y2, parent, score, steps, state):
        self.x1 = x1 
        self.y1 = y1
        self.x2 = x2
        self.y2 = y2
        self.steps = steps
        self.score = score
        self.parent = parent
        self.state = state
