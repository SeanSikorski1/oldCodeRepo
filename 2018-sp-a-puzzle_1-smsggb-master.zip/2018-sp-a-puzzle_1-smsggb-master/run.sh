python ./main.py
