#############################################################################
#Sean Sikorski                                              completed:2/10/18
#mainfunc.py                                                      compsci5400
#############################################################################
#this file contains the meat and potatoes of this entire program. functions 
#that will be used in main function can be found here and only here 
#(besides the datetime functions)
#############################################################################
#imports
import agent#agent holds the node class
import rules#rules holds the rules class
import copy#used for creating a deepcopy of the puzzle when creating child 
           #nodes

#############################################################################
#debug functions

#prints the puzzle without the pool
def printGrid(grid, rules):
    for y in range(rules.h):
        print(grid[y+rules.poolH])

#prints the puzzle with the pool
def printFull(grid, rules):
    for y in range(rules.h+rules.poolH):
        print(grid[y])

#############################################################################
#main functions

#checks if the current node is a goal state
def isGoal(rules, node):
    if(node.score >= rules.quota):
        return True
    return False

#checks if the current node has reached max steps
def overStep(rules, node):
    if(node.steps >= rules.moves):
        return True
    return False

#Converts the grid into a hash that allows it to be compared to other hashes 
#   easily
def gridHash(grid):
    copy = []
    for row in grid:
        copy.append(tuple(row))
    
    copy = tuple(copy)
    return hash(copy)

#for this version of the final puzzle AI I used hashes to save on storage making
#   comparisons between new nodes and already traversed nodes. 
def gridCompare(grid, collection):
    temp = gridHash(grid)#convert grid to hash
    for x in collection:
        if(x == temp):#if grid already traversed then return true
            return True
    collection.append(temp)#otherwise add it to the traversed list
    return False


#checks the given grid if the vicinity of x y has any "jewels" similair to the
#  one given. direction represents the direction you are checking to make a 
#  swap. This helps prevent false positives in special cases and leaves room 
#  to check for additional matches after the grid has repopulated
def isMatch(grid, rules, x, y, unit, direction):
    mCountX = 0 #keeps track of the amount matched in the x direction
    mCountY = 0 #keeps track of the amount matched in the y direction
    if(direction == 'YR' or direction == 'YL'):#if swapping below or above
        mCountX = 1 #give x an extra unit because it would miss it otherwise
    if(direction == 'XR' or direction == 'XL'):#if swapping right or left
        mCountY = 1 #give y an extra unit because it would miss it otherwise
    if(direction != 'XR'):#if coming from the right don't search that direction
        temp = 1
        #essentially these while loops check a given direction until the unit
        #doesn't match, incrementing their given count until failure
        while(x+temp < rules.w and grid[y][x+temp] == unit):
            mCountX += 1
            temp += 1
    if(direction != 'XL'):#if coming from the left don't search that direction
        temp = 1
        while(x-temp >= 0 and grid[y][x-temp] == unit):
            mCountX += 1
            temp += 1
    if(direction != 'YR'):#below
        temp = 1
        while(y+temp < rules.h+rules.poolH and grid[y+temp][x] == unit):
            mCountY += 1
            temp += 1
    if(direction != 'YL'):#above
        temp = 1
        while(y-temp >= rules.poolH and grid[y-temp][x] == unit):
            mCountY += 1
            temp += 1
    if(mCountX > mCountY):
        return mCountX
    return mCountY


#this repopulates the grid as specified in the project url
def repop(grid, rules):
    total = 1
    for y in range(rules.poolH + rules.h):
        for x in range(rules.w):
            if(grid[y][x] == 0 and y != 0):
                grid[y][x] = grid[y-1][x]
                i = y - 1
                while(i > 0):
                    grid[i][x] = grid[i-1][x]
                    i -= 1
                grid[0][x] = ((grid[1][x] + x + total) % rules.devTypes) + 1
                total += 1
    return total


#**NEW**
#this is a recursive way of finding and removing any special cases
#such as the H matches and other "branching" matches that wouldn't be
#found in the base method of match() (called in match())
def branchKiller(grid, rules, x, y, unit, direction):
    temp = 1
    score = 0
    xCount = 0 #keep tally of possible branches in the X direction
    yCount = 0 #tally for the Y direction
    #if the prev function was already searching in the X direction there is 
    #no reason to check it twice
    if(direction == "X"): 
        while(y+temp < rules.h + rules.poolH and grid[y+temp][x] == unit):
            yCount += 1
            temp += 1
        temp = 1
        while(y-temp >= rules.poolH and grid[y-temp][x] == unit):
            yCount += 1
            temp += 1
    #prevents searching Y direction more than once
    if(direction == "Y"):
        while(x+temp < rules.w and grid[y][x+temp] == unit):
            xCount += 1
            temp += 1
        temp = 1
        while(x-temp >= 0 and grid[y][x-temp] == unit):
            xCount += 1
            temp += 1
    temp = 1
    #if either iterators is 2 or more than a branch has been found
    if(yCount >= 2):
        while(y+temp < rules.h + rules.poolH and grid[y+temp][x] == unit):
            grid[y+temp][x] = 0
            score += 1
            #checks if the branch has branches
            score += branchKiller(grid, rules, x, y+temp, unit, "Y")
            temp += 1
        temp = 1
        while(y-temp >= rules.poolH and grid[y-temp][x] == unit):
            grid[y-temp][x] = 0
            score += 1
            score += branchKiller(grid, rules, x, y-temp, unit, "Y")
            temp += 1
    if(xCount >= 2):
        while(x+temp < rules.w and grid[y][x+temp] == unit):
            grid[y][x+temp] = 0
            score += 1
            score += branchKiller(grid, rules, x+temp, y, unit, "X")
            temp += 1
        temp = 1
        while(x-temp >= 0 and grid[y][x-temp] == unit):
            grid[y][x-temp] = 0
            score += 1
            score += branchKiller(grid, rules, x-temp, y, unit, "X")
            temp += 1
    return score


#only called when a match is confirmed, this function will replace all similair
#units with the empty unit 0. each time this happens it will increment the 
#overall score of this match and return it. similair to isMatch() in execution
def match(grid, rules, x, y):
    unit = int(grid[y][x])
    grid[y][x] = 0
    mCountX = 0
    mCountY = 0
    score = 1
    #ensures that we are only removing matches of three and up
    temp = 1
    while(x+temp < rules.w and grid[y][x+temp] == unit):
        mCountX += 1
        temp += 1
    temp = 1
    while(x-temp >= 0 and grid[y][x-temp] == unit):
        mCountX += 1
        temp += 1
    temp = 1
    while(y+temp < rules.h+rules.poolH and grid[y+temp][x] == unit):
        mCountY += 1
        temp += 1
    temp = 1
    while(y-temp >= rules.poolH and grid[y-temp][x] == unit):
        mCountY += 1
        temp += 1

    if(mCountY >= 2):
        temp = 1
        while(y+temp < rules.h+rules.poolH and grid[y+temp][x] == unit):
            grid[y+temp][x] = 0
            score += 1
            score += branchKiller(grid, rules, x, y+temp, unit, "Y")
            temp += 1
        temp = 1
        while(y-temp >= rules.poolH and grid[y-temp][x] == unit):
            grid[y-temp][x] = 0
            score += 1
            score += branchKiller(grid, rules, x, y-temp, unit, "Y")
            temp += 1
    #center is not included in the score of mcountx and mcounty so 2 is the 
    #number we look for
    if(mCountX >= 2):
        temp = 1
        while(x+temp < rules.w and grid[y][x+temp] == unit):
            grid[y][x+temp] = 0
            score += 1
            score += branchKiller(grid, rules, x+temp, y, unit, "X")
            temp += 1
        temp = 1
        while(x-temp >= 0 and grid[y][x-temp] == unit):
            grid[y][x-temp] = 0
            score += 1
            score += branchKiller(grid, rules, x-temp, y, unit, "X")
            temp += 1
    return score


#this function will be called post match to check for new matches after the
#puzzle has repopulated and ensures that node is given the appropriate 
#amount of points
def bonusMatch(grid, rules):
    score = 0
    matchfound = True #attempt at a do while loop
    while(matchfound):
        matchfound = False
        for y in range(rules.h):
            for x in range(rules.w):
                if(grid[y+rules.poolH][x] != 0 and isMatch(grid,rules, x, y+rules.poolH, grid[y+rules.poolH][x], "N") >= 2):
                    matchfound = True
                    score += match(grid, rules, x, y+rules.poolH)
        repop(grid,rules)
    return score


#this is essentially the Action() function. this will execute the swap for the
#node and subsequently deals out the points for the given node for completing 
#the task. This also contains the step counter. 
def swap(node, rules):
    node.steps += 1
    temp = node.state[node.y1][node.x1]
    node.state[node.y1][node.x1] = node.state[node.y2][node.x2]
    node.state[node.y2][node.x2] = temp
    node.score += match(node.state, rules, node.x2, node.y2)
    node.score += bonusMatch(node.state, rules)

############### GRAPH SEARCH IS IN HERE #################################
#this function searches the grid for all possible matches. When a match is 
#found it will then create a node that will be given the task to complete that
#match when called upon. These nodes are then stored as an array in temp and 
#returned to be extended into the frontier 
def formFirstFrontier(grid, rules, traversed):
    temp = []
    temp2 = []
    for y in range(rules.h):
        for x in range(rules.w):
            if(x != rules.w-1):
                if(isMatch(grid, rules, x+1, y+rules.poolH, grid[y+rules.poolH][x], "XR") >= 3):
                    temp.append(agent.node(x, y+rules.poolH, x+1, y+rules.poolH, None, 0, 0, copy.deepcopy(grid)))
            if(x > 0):
                if(isMatch(grid, rules, x-1, y+rules.poolH, grid[y+rules.poolH][x], "XL") >= 3):
                    temp.append(agent.node(x, y+rules.poolH, x-1, y+rules.poolH, None, 0, 0, copy.deepcopy(grid)))
            if(y != rules.h-1):
                if(isMatch(grid, rules, x, y+rules.poolH+1, grid[y+rules.poolH][x], "YR") >= 3):
                    temp.append(agent.node(x, y+rules.poolH, x, y+rules.poolH+1, None, 0, 0, copy.deepcopy(grid)))
            if(y > 0):
                if(isMatch(grid, rules, x, y+rules.poolH-1, grid[y+rules.poolH][x], "YL") >= 3):
                    temp.append(agent.node(x, y+rules.poolH, x, y+rules.poolH-1, None, 0, 0, copy.deepcopy(grid)))
    #for every node in temp we run their designated swap
    for x in temp:
        swap(x, rules)
    #then if we have already had the same state as before, delete it, otherwise add it to temp2 and the state is 
    #   added to the traversed list
    while(len(temp) != 0):
        if(gridCompare(copy.deepcopy(temp[0].state),traversed)):
            del temp[0]
        else:
	    temp2.append(temp.pop(0))

    return temp2


#this function is similair to the one above but each node created now has a
#parent to rely on and pool score and steps with
def formNextFrontier(grid, rules, parent, traversed):
    temp = []
    temp2 = []#this will the the transfer for temp to check for repeat states
    for y in range(rules.h):
        for x in range(rules.w):
            if(x != rules.w-1):
                if(isMatch(grid, rules, x+1, y+rules.poolH, grid[y+rules.poolH][x], "XR") >= 3):
                    temp.append(agent.node(x, y+rules.poolH, x+1, y+rules.poolH, parent, parent.score, parent.steps, copy.deepcopy(grid)))
            if(x > 0):
                if(isMatch(grid, rules, x-1, y+rules.poolH, grid[y+rules.poolH][x], "XL") >= 3):
                    temp.append(agent.node(x, y+rules.poolH, x-1, y+rules.poolH, parent, parent.score, parent.steps, copy.deepcopy(grid)))
            if(y != rules.h-1):
                if(isMatch(grid, rules, x, y+rules.poolH+1, grid[y+rules.poolH][x], "YR") >= 3):
                    temp.append(agent.node(x, y+rules.poolH, x, y+rules.poolH+1, parent, parent.score, parent.steps, copy.deepcopy(grid)))
            if(y > 0):
                if(isMatch(grid, rules, x, y+rules.poolH-1, grid[y+rules.poolH][x], "YL") >= 3):
                    temp.append(agent.node(x, y+rules.poolH, x, y+rules.poolH-1, parent, parent.score, parent.steps, copy.deepcopy(grid)))

    for x in temp:
        swap(x, rules)
    
    while(len(temp) != 0):
        if (gridCompare(copy.deepcopy(temp[0].state),traversed)):
            del temp[0]
        else:
            temp2.append(temp.pop(0))

    return temp2


#once a match is found this function can climb the tree of nodes adding each 
#node's action to a list, reverse it, then print it to the screen to show the
#given path found to the goal
#args allows you to specify which puzzle is being solved and ensure you pull from
#the right file
def printPath(node, f, args):
    temp = []
    f2 = open("input"+str(args.input)+".txt")
    f.write(f2.read())
    temp.append("("+str(node.x1)+","+str(node.y1)+"),("+str(node.x2)+","+str(node.y2)+")")
    i = node.parent
    while(i != None):
        temp.append("("+str(i.x1)+","+str(i.y1)+"),("+str(i.x2)+","+str(i.y2)+")")
        i = i.parent
    temp.reverse()
    for match in temp:
        f.write(match + "\n")
