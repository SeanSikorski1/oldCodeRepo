// AI
// This is where you build your AI

#include "ai.hpp"

// <<-- Creer-Merge: includes -->> - Code you add between this comment and the end comment will be preserved between Creer re-runs.
// You can add #includes here for your AI.
// <<-- /Creer-Merge: includes -->>

namespace cpp_client
{

namespace chess
{
//#######################################################################################
//#Sean Sikorski
//#ai.cpp
//#######################################################################################
//#I couldn't figure out how to get seperate files going while still maintaining access
//#to the AI and Chess structs so this and the header contain all the structs and 
//#functions to get the AI going
//#######################################################################################
//#moveList constructors including default, with and without parents
moveList::moveList()
{
    rank = 10; //outlandish number to check if not initialized
}

moveList::moveList(moveList item, int y, std::string x, int moveY, std::string moveX, int amount)
{
    parent = &item;
    rank = y;
    file = x;
    moveRank = moveY;
    moveFile = moveX;
    score = amount;
}

moveList::moveList(int y, std::string x, int moveY, std::string moveX, int amount)
{
    parent = nullptr;
    rank = y;
    file = x;
    moveRank = moveY;
    moveFile = moveX;
    score = amount;
}
//#moveList end
//#######################################################################################

/// <summary>
/// This returns your AI's name to the game server.
/// Replace the string name.
/// </summary>
/// <returns>The name of your AI.</returns>
std::string AI::get_name() const
{
    // <<-- Creer-Merge: get-name -->> - Code you add between this comment and the end comment will be preserved between Creer re-runs.
    // REPLACE WITH YOUR TEAM NAME!
    return "Sean Sikorski";
    // <<-- /Creer-Merge: get-name -->>
}

/// <summary>
/// This is automatically called when the game first starts, once the game objects are created
/// </summary>
void AI::start()
{
    // <<-- Creer-Merge: start -->> - Code you add between this comment and the end comment will be preserved between Creer re-runs.
    srand(time(NULL));//using random to pick from the moves generated

    // This is a good place to initialize any variables
    // <<-- /Creer-Merge: start -->>
}


/// <summary>
/// This is automatically called the game (or anything in it) updates
/// </summary>
void AI::game_updated()
{
    // <<-- Creer-Merge: game-updated -->> - Code you add between this comment and the end comment will be preserved between Creer re-runs.
    // If a function you call triggers an update this will be called before it returns.
    // <<-- /Creer-Merge: game-updated -->>
}

/// <summary>
/// This is automatically called when the game ends.
/// </summary>
/// <param name="won">true if you won, false otherwise</param>
/// <param name="reason">An explanation for why you either won or lost</param>
void AI::ended(bool won, const std::string& reason)
{
    //<<-- Creer-Merge: ended -->> - Code you add between this comment and the end comment will be preserved between Creer re-runs.
    // You can do any cleanup of your AI here.  The program ends when this function returns.
    //<<-- /Creer-Merge: ended -->>
}

/// <summary>
/// This is called every time it is this AI.player's turn.
/// </summary>
/// <returns>Represents if you want to end your turn. True means end your turn, False means to keep your turn going and re-call this function.</returns>
bool AI::run_turn()
{
    // <<-- Creer-Merge: runTurn -->> - Code you add between this comment and the end comment will be preserved between Creer re-runs.
    //##################################################################################
    //############################RUN TURN START########################################
    std::vector<moveList> movelist;//list of possible moves
    std::vector<moveList> enemyMoves;
    chess::Piece randPiece = nullptr;//initialized later when choosing a move to make
    moveList curMove;//also initialized later when choosing a move to make
    char curState[8][8];//current state of the board
    bool riskState[8][8];//help calc score and prevent king from moving into check
    bool occState[8][8];
    //###################################################################################
    //vvvvvvvvvvvvvvvvv-Map Initializer-#################################################
    genState(curState);

    for(int i = 0; i<8; i++)
	for(int j=0;j<8;j++)
	{
	    occState[i][j] = false;
	}
    occupancyTest(occState,player->color,curState); 
    //###################################################################################
    //vvvvvvvvvvvvvvvvvv-riskState initializer-##########################################
    for(int i=0;i<8;i++)
	for(int j=0;j<8;j++)
	    riskState[i][j] = false;

    enemyMoves = createMoves(curState, player->opponent->color, riskState, occState);

    genRisk(riskState,curState);

    std::cout<<std::endl;
    
    //###################################################################################
    //vvvvv-pushes all possible moves unto move list-vvvvv###############################
    movelist = createMoves(curState, player->color, riskState, occState);//color is a set up for minmax    
    for(unsigned i = 0; i<movelist.size(); i++)
    {
	if(futureCheck(movelist[i],curState, player->color)){}
	    //movelist.erase(movelist.begin()+i);
    }
    //###################################################################################
    //vvvvv-Move Generation-vvvvv########################################################

    //guided random move generation for when in check
    if(player->in_check)//god save the king
    {
	chess::Piece king = nullptr;
	for(const auto& piece: player->pieces)
	    if(piece->type == "King")
	    {
		king = piece;
		break;
	    }
	for(const auto& move: movelist)
	    if(king->rank == move.rank && king->file == move.file)
	    {
		curMove = move;
		break;
	    }
	if(curMove.rank != 10)
	{
	    printMove(king,curMove);
	    printMoves(king, movelist);
	    king->move(curMove.moveFile, curMove.moveRank);
	}
	//When king can't move, this tries and find a way to kill the person
	//     attacking the king
	else//I'll save the king
	{
	    moveList enemy;
	    moveList hero;
	    chess::Piece savior = nullptr;
	    for(const auto& move: enemyMoves)
		if(move.moveRank == king->rank && move.moveFile == king->file)
		{
		    enemy = move;
		    break;
		}
	    if(enemy.rank == 10)
		std::cout<<"something went wrong"<<std::endl;
	    for(const auto& move: movelist)
		if(move.moveRank == enemy.rank && move.moveFile == enemy.file)
		{
		    hero = move;
		    break;
		}
	    if(hero.rank != 10)
	    {
		for(const auto& piece: player->pieces)
		    if(piece->rank == hero.rank && piece->file == hero.file)
		    {
			savior = piece;
			break;
		    }
		if(savior == nullptr)
		    std::cout<<"something went wrong 2"<<std::endl;
		else 
		{
		    printMove(savior, hero);
		    printMoves(savior, movelist);
		    savior->move(hero.moveFile,hero.moveRank);
		}
	    }
	}
    }
    //else just regurlar random move generation
    else
    {
        curMove = movelist[rand() % movelist.size()];
	for(const auto& piece : player->pieces)
	    if(piece->file == curMove.file && piece->rank == curMove.rank)
	    {
		randPiece = piece;
		break;
	    }
	if(randPiece->type=="Pawn")
	{
	    if(player->color == "White" && curMove.moveRank == 8)
	    {
		printMove(randPiece,curMove);
		std::cout<<"Piece Promoted To Queen"<<std::endl;
	        printMoves(randPiece, movelist);
		randPiece->move(curMove.moveFile,curMove.moveRank,"Queen");
	    }
	    else if(player->color == "Black" && curMove.moveRank == 1)
	    {
		printMove(randPiece,curMove);
		std::cout<<"Piece Promoted To Queen"<<std::endl;
		printMoves(randPiece, movelist);
		randPiece->move(curMove.moveFile,curMove.moveRank,"Queen");
	    }
	    else
	    {
		printMove(randPiece,curMove);
		printMoves(randPiece,movelist);
		randPiece->move(curMove.moveFile,curMove.moveRank);
	    }
	}
	else
	{
	    printMove(randPiece,curMove);
	    printMoves(randPiece,movelist);
	    randPiece->move(curMove.moveFile,curMove.moveRank);
	}
    }

    return true;
    //#############################RUN TURN END##########################################
    //###################################################################################

    // Put your game logic here for run_turn here
    // <<-- /Creer-Merge: runTurn -->>
}

//<<-- Creer-Merge: methods -->> - Code you add between this comment and the end comment will be preserved between Creer re-runs.
// You can add additional methods here for your AI to call
//<<-- /Creer-Merge: methods -->>

//#######################################################################################
//generates the current state of the game (should probably go in update but it crashed
//  when I did that)

//#######################################################################################
//Junk function that prints all possible moves of the piece given
void AI::printMove(const chess::Piece piece, const moveList move)
{
    std::cout<<std::endl<<piece->owner->color<<" "<<piece->type<<" from ";
    std::cout<<move.file<<move.rank<<" to "<<move.moveFile<<move.moveRank;
    std::cout<<std::endl;
    return;
}

void AI::printMoves(const chess::Piece piece, const std::vector<moveList> movelist)
{
    std::cout<<std::endl<<"All Possible Moves Of This "<<piece->type<<"."<<std::endl;

    for(const auto& move : movelist)
	if(move.file == piece->file && move.rank == piece->rank)
	{
	    std::cout<<move.file<<move.rank<<"->"<<move.moveFile<<move.moveRank<<std::endl;
	}

    return;
}

void AI::genState(char (&state)[8][8])
{
    //initialize the grid with periods for no piece here
    for(int i=0; i<8; i++)
    {
	for(int j=0; j<8; j++)
	    state[i][j] = '.'; 
    }

    //walks through all the pieces in the game and places 
    //  them on the grid in their respective locations
    for(const auto& piece : game->pieces)
    {
	int file = (int)piece->file[0] - 97;//convert file string to int from ascci
	int rank = piece->rank-1;
	char type = (char)piece->type[0];//grabs the first letter of the piece type
	if(piece->type == "Knight")//K is already used by king so knight is N
	    type = 'N';
	if(piece->owner->id == "1")//if the peice is black (1) it is lowercase
	    type = tolower(type);
	state[rank][file] = type;//place type letter on the grid
    }

    //DEBUG: prints the state
    for(int i=0; i<8; i++)
    {
	std::cout<<std::endl;
	for(int j=0; j<8; j++)
	    std::cout<<state[i][j];
    }

    return;
}


//#######################################################################################
//checks if a position is occupied by a unit of the given color

bool AI::isOccupied(int x, int y, std::string color, const char state[8][8])
{
    if(x > 7 || y > 7 || x < 0 || y < 0)//prevent walking off array
	return true;
    bool occupied = false;//if occupied initializer
    char temp = state[x][y];//reduce bulk
    //vvvv-peices that we are looking for-vvvv
    char pawn = 'P', knight = 'N', rook = 'R', bishop = 'B', queen = 'Q', king = 'K';
    if(color == "Black")//if color is black then change pieces to lowercase
    {
	pawn = tolower(pawn);
	knight = tolower(knight);
	rook = tolower(rook);
	bishop = tolower(bishop);
	queen = tolower(queen);
	king = tolower(king);
    }
    //if the current char at position [x][y] is representive of a piece then return true
    if(temp == pawn || temp == knight || temp == rook || temp == bishop || temp == queen || temp == king)
	occupied = true;
    return occupied;
}

void AI::occupancyTest(bool (&house)[8][8], std::string color, const char state[8][8])
{
    for(int i=0;i<8;i++)
	for(int j=0;j<8;j++)
	    house[i][j] = isOccupied(i, j, color, state);
    return;
}

//#######################################################################################
//checks a location for a piece of opposite color returns a score that is dependent on
//the piece found (if at all)

int enemyOccupied(int x, int y, std::string color, const char state[8][8])
{
    if(x > 7 || y > 7 || x < 0 || y < 0)//prevent walking off array
	return 0;
    int score = 0;//if 0 then not occupied
    char temp = state[x][y];//bulk reducer
    //vvvvv-pieces that we are looking for
    char pawn = 'P', knight = 'N', rook = 'R', bishop = 'B', queen = 'Q', king = 'K';
    if(color == "White")//looking for enemy team
    {
        pawn = tolower(pawn);
        knight = tolower(knight);
        rook = tolower(rook);
        bishop = tolower(bishop);
        queen = tolower(queen);
        king = tolower(king);
    }
    
    //generate score off of possible capture 
    if(temp == pawn)
	score = 1;
    else if(temp == knight)
        score = 3;
    else if(temp == bishop)
        score = 3;
    else if(temp == rook)
        score = 5;
    else if(temp == queen)
        score = 9;
    else if(temp == king)
        score = 10;

    return score;//if score is 0 then no enemy at this location
}

//#######################################################################################
//takes a move and generates a future risk map, then checks if this move will put our 
//king in check, if it does we return true
//**********************not used as it is too harsh right now****************************
//needs reworking

bool AI::futureCheck(moveList move, const char state[8][8], std::string color)
{
    bool futRisk[8][8];
    char futState[8][8];
    bool atRisk = false;
    int rank = move.rank - 1;
    int file = (int)move.file[0] - 97;
    int moveRank = move.moveRank -1;
    int moveFile = (int)move.moveFile[0] - 97;
    int kingx = 10,kingy = 10;

    for(int i=0;i<8;i++)
	for(int j=0;j<8;j++)
	    futState[i][j] = state[i][j];

    futState[moveRank][moveFile] = futState[rank][file];
    futState[rank][file] = '.';

    genRisk(futRisk,futState);

    for(int i=0;i<8;i++)
	for(int j=0;j<8;j++)
	{
	    if(color == "Black" && state[i][j] == 'k')
	    {
		kingx = i;
		kingy = j;
	    }
	    else if(color == "White" && state[i][j] == 'K')
	    {
		kingx = i;
		kingy = j;
	    }
	}
    if(kingx == 10 || kingy == 10)
	std::cout<<"kings not found"<<std::endl;
    if(futRisk[kingx][kingy] == true)
	atRisk = true;

    return atRisk;
}

//#######################################################################################
//generates possible moves for the pawn at the given location

std::vector<moveList> AI::pawnMoves(int x, int y, const char state[8][8], std::string color, const bool risk[8][8], const bool occState[8][8])
{
    std::vector<moveList> movelist;
    int rank = x+1;
    std::string file(1, 'a'+y);
    bool enemyOcc[8][8];
    occupancyTest(enemyOcc, player->opponent->color, state);

    int capture;//carries score from any possible captures
    //probably one of the more tedious pieces because they have a specified direction 
    //they need to follow depending on color
    //moving 'forward' 1 space
    if(color == "White" && !isOccupied(x+1,y,"White",state) && !isOccupied(x+1,y,"Black",state) && !occState[x+1][y] && !enemyOcc[x+1][y])
    {
	moveList temp(rank, file, rank+1, file, 0);
	movelist.push_back(temp);
    }
    else if(color == "Black" && !isOccupied(x-1,y,"Black",state) && !isOccupied(x+1,y,"White",state) && !occState[x-1][y] && !enemyOcc[x-1][y])
    {
	moveList temp(rank, file, rank-1, file, 0);
	movelist.push_back(temp);
    }

    //moving diagnol in case of capture
    if(color == "White")
    {
	capture = enemyOccupied(x+1,y+1,"White",state);
	if(capture > 0)
	{
	    std::string newfile(1, 'a'+(y+1));
	    moveList temp(rank, file, rank+1, newfile, capture);
	    movelist.push_back(temp);
	}
	capture = enemyOccupied(x+1,y-1,"White",state);
	if(capture > 0)
	{
	    std::string newfile(1, 'a'+(y-1));
	    moveList temp(rank, file, rank+1, newfile, capture);
	    movelist.push_back(temp);
	}
    }
    else if(color == "Black")
    {
	capture = enemyOccupied(x-1,y+1,"Black",state);
	if(capture > 0)
	{
	    std::string newfile(1, 'a'+(y+1));
	    moveList temp(rank, file, rank-1, newfile, capture);
	    movelist.push_back(temp);
	}
	capture = enemyOccupied(x-1,y-1,"Black",state);
	if(capture > 0)
	{
	    std::string newfile(1, 'a'+(y-1));
	    moveList temp(rank, file, rank-1, newfile, capture);
	    movelist.push_back(temp);
	}
    }

    return movelist;//return list of moves made
}

//#######################################################################################
//generates possible moves for the knight

std::vector<moveList> AI::knightMoves(int x, int y, const char state[8][8], std::string color, const bool risk[8][8], const bool occState[8][8])
{
    std::vector<moveList> movelist;
    int rank = x+1;
    std::string file(1, 'a'+y);
    int score;

    //the most straight forward of the bunch, since it can jump over friendlys we only
    //need to worry about where he lands and we don't have to worry about looping 
    //::So essentially this checks all locations that the knight can move and checks if
    //  freindlys are there. If not it generates a move for the knight.
    if(!isOccupied(x+2,y+1,color,state) && !occState[x+2][y+1])
    {
	std::string newfile(1, 'a'+(y+1));
	score = enemyOccupied(x+2,y+1,color,state);
	moveList temp(rank, file, rank+2, newfile, score);
	movelist.push_back(temp);
    }
    
    if(!isOccupied(x+2,y-1,color,state) && !occState[x+2][y-1])
    {
	std::string newfile(1, 'a'+(y-1));
	score = enemyOccupied(x+2,y-1,color,state);
	moveList temp(rank, file, rank+2, newfile, score);
	movelist.push_back(temp); 
    }

    if(!isOccupied(x-2,y+1,color,state) && !occState[x-2][y+1])
    {
	std::string newfile(1, 'a'+(y+1));
	score = enemyOccupied(x-2,y+1,color,state);
	moveList temp(rank, file, rank-2, newfile, score);
	movelist.push_back(temp);
    }

    if(!isOccupied(x-2,y-1,color,state) && !occState[x-2][y-1])
    {
        std::string newfile(1, 'a'+(y-1));
        score = enemyOccupied(x-2,y-1,color,state);
        moveList temp(rank, file, rank-2, newfile, score);
        movelist.push_back(temp);
    }

    if(!isOccupied(x+1,y+2,color,state) && !occState[x+1][y+2])
    {
        std::string newfile(1, 'a'+(y+2));
        score = enemyOccupied(x+1,y+2,color,state);
        moveList temp(rank, file, rank+1, newfile, score);
        movelist.push_back(temp);
    }

    if(!isOccupied(x-1,y+2,color,state) && !occState[x-1][y+2])
    {
        std::string newfile(1, 'a'+(y+2));
        score = enemyOccupied(x-1,y+2,color,state);
        moveList temp(rank, file, rank-1, newfile, score);
        movelist.push_back(temp);
    }

    if(!isOccupied(x+1,y-2,color,state) && !occState[x+1][y-2])
    {
        std::string newfile(1, 'a'+(y-2));
        score = enemyOccupied(x+1,y-2,color,state);
        moveList temp(rank, file, rank+1, newfile, score);
        movelist.push_back(temp);
    }

    if(!isOccupied(x-1,y-2,color,state) && !occState[x-1][y-2])
    {
        std::string newfile(1, 'a'+(y-2));
        score = enemyOccupied(x-1,y-2,color,state);
        moveList temp(rank, file, rank-1, newfile, score);
        movelist.push_back(temp);
    }


    return movelist;
}

//#######################################################################################
//generates possible bishop moves

std::vector<moveList> AI::bishopMoves(int x, int y, const char state[8][8], std::string color, const bool risk[8][8], const bool occState[8][8])
{
    std::vector<moveList> movelist;
    bool UL = false, UR =false, LL = false, LR = false;//direction cappers
    int dist = 1;//distance from origin
    int rank = x+1;
    std::string file(1, 'a'+y);
    int score;

    //bishop and rook rely on looping to find possible moves
    //the bishop looks in an x direction gradually making the x larger until all caps are
    //called on the x.
    //caps are called when there is a friendly blocking the way or when an enemy is 
    //blocking the way but a move is still generated on their location. 
    do{

	if(!UL)//if upperleft isn't capped
	{
	    if(!isOccupied(x+dist,y-dist,color,state) && !occState[x+dist][y-dist])
	    {
		std::string newfile(1, 'a'+(y-dist));
		score = enemyOccupied(x+dist,y-dist,color,state);
		moveList temp(rank,file,rank+dist,newfile,score);
		movelist.push_back(temp);
		if(score > 0)
		    UL = true;
	    }
	    else
	        UL = true;
	}
	if(!UR)//if upperright isn't capped
	{
	    if(!isOccupied(x+dist,y+dist,color,state) && !occState[x+dist][y+dist])
	    {
		std::string newfile(1, 'a'+(y+dist));
		score = enemyOccupied(x+dist,y+dist,color,state);
		moveList temp(rank,file,rank+dist,newfile,score);
		movelist.push_back(temp);
		if(score > 0)
		    UR = true;
	    }
	    else
		UR = true;
	}
	if(!LL)//if lowerleft isn't capped
	{
	    if(!isOccupied(x-dist,y-dist,color,state) && !occState[x-dist][y-dist])
	    {
		std::string newfile(1, 'a'+(y-dist));
		score = enemyOccupied(x-dist,y-dist,color,state);
		moveList temp(rank,file,rank-dist,newfile,score);
		movelist.push_back(temp);
		if(score > 0)
		    LL = true;
	    }
	    else
		LL = true;
	}
	if(!LR)//if lowerright isn't capped
	{
	    if(!isOccupied(x-dist,y+dist,color,state) && !occState[x-dist][y+dist])
	    {
		std::string newfile(1, 'a'+(y+dist));
		score = enemyOccupied(x-dist,y+dist,color,state);
		moveList temp(rank,file,rank-dist,newfile,score);
		movelist.push_back(temp);
		if(score > 0)
		    LR = true;
	    }
	    else
		LR = true;
	}

	dist++;//increment distance
    }while(!UL || !UR || !LL || !LR);


    return movelist;
}

//#######################################################################################
//gen possible moves for the rook

std::vector<moveList> AI::rookMoves(int x, int y, const char state[8][8], std::string color, const bool risk[8][8], const bool occState[8][8])
{
    std::vector<moveList> movelist;
    bool L = false, R = false, U = false, D = false;//direction cappers
    int dist = 1;
    int rank = x+1;
    std::string file(1, 'a'+y);
    int score;

    //similair to bishops move generator but moves in a + instead of an x
    do{
        if(!L)//if left not capped
        {
            if(!isOccupied(x,y-dist,color,state) && !occState[x][y-dist])//if spot isn't occupied by friendly
            {
                std::string newfile(1, 'a'+(y-dist));
                score = enemyOccupied(x,y-dist,color,state);//check for capture
                moveList temp(rank,file,rank,newfile,score);//generate move
                movelist.push_back(temp);//add move to list
                if(score > 0)//if you also captured a piece then stop looking this way
                    L = true;
            }
            else
                L = true;
        }
        if(!R)//if right not capped
        {
            if(!isOccupied(x,y+dist,color,state) && !occState[x][y+dist])
            {
                std::string newfile(1, 'a'+(y+dist));
                score = enemyOccupied(x,y+dist,color,state);
                moveList temp(rank,file,rank,newfile,score);
                movelist.push_back(temp);
                if(score > 0)
                    R = true;
            }
            else
                R = true;
        }
        if(!U)//if up not capped
        {
            if(!isOccupied(x+dist,y,color,state) && !occState[x+dist][y])
            {
                score = enemyOccupied(x+dist,y,color,state);
                moveList temp(rank,file,rank+dist,file,score);
                movelist.push_back(temp);
                if(score > 0)
                    U = true;
            }
            else
                U = true;
        }
        if(!D)//if down not capped
        {
            if(!isOccupied(x-dist,y,color,state) && !occState[x-dist][y])
            {
                score = enemyOccupied(x-dist,y,color,state);
                moveList temp(rank,file,rank-dist,file,score);
                movelist.push_back(temp);
                if(score > 0)
                    D = true;
            }
            else
                D = true;
        }

        dist++;

    }while(!L || !R || !U || !D);//only when all ends have been capped can this stop

    return movelist;
}

//#######################################################################################
//generate possible moves for the queen

std::vector<moveList> AI::queenMoves(int x, int y, const char state[8][8], std::string color, const bool risk[8][8], const bool occState[8][8])
{
    std::vector<moveList> movelist;
    std::vector<moveList> temp;
    //essentially highjacks the rook and bishop functions since it can do both of their move sets 
    //get diagonal moves
    temp = bishopMoves(x,y,state,color,risk, occState);
    movelist.insert(movelist.end(), temp.begin(), temp.end());
    //get vertical and horizontal moves
    temp = rookMoves(x,y,state,color,risk, occState);
    movelist.insert(movelist.end(), temp.begin(), temp.end());
 
    return movelist;
}

//#######################################################################################
//generate possible moves for the king

std::vector<moveList> AI::kingMoves(int x, int y, const char state[8][8], std::string color, const bool risk[8][8], const bool occState[8][8])
{
    std::vector<moveList> movelist;
    int rank = x+1;
    std::string file(1, 'a'+y);
    int score;

    //the king is fairly tricky because he can't move into spaces that are at risk of 
    //putting him in check so we use the risk board for this
    //::essentially this searchs all directions for if they are occupied then if not 
    //  if they are at risk of putting the king in check.
    //  once both are false then we can generate a move for the king
    if(!isOccupied(x+1,y,color,state) && !risk[x+1][y] && !occState[x+1][y])//up
    {
	score = enemyOccupied(x+1,y,color,state);
	moveList temp(rank,file,rank+1,file,score);
	movelist.push_back(temp);
    }
    if(!isOccupied(x-1,y,color,state) && !risk[x-1][y] && !occState[x-1][y])//down
    {
	score = enemyOccupied(x-1,y,color,state);
	moveList temp(rank,file,rank-1,file,score);
	movelist.push_back(temp);
    }
    if(!isOccupied(x,y+1,color,state) && !risk[x][y+1] && !occState[x][y+1])//right
    {
	score = enemyOccupied(x,y+1,color,state);
	std::string newfile(1, 'a'+(y+1));
	moveList temp(rank,file,rank,newfile,score);
	movelist.push_back(temp);
    }
    if(!isOccupied(x,y-1,color,state) && !risk[x][y-1] && !occState[x][y-1])//left
    {
        score = enemyOccupied(x,y-1,color,state);
        std::string newfile(1, 'a'+(y-1));
        moveList temp(rank,file,rank,newfile,score);
        movelist.push_back(temp);
    }
    if(!isOccupied(x+1,y+1,color,state) && !risk[x+1][y+1] && !occState[x+1][y+1])//upper right
    {
        score = enemyOccupied(x+1,y+1,color,state);
        std::string newfile(1, 'a'+(y+1));
        moveList temp(rank,file,rank+1,newfile,score);
        movelist.push_back(temp);
    }
    if(!isOccupied(x+1,y-1,color,state) && !risk[x+1][y-1] && !occState[x+1][y-1])//upper left
    {
        score = enemyOccupied(x,y-1,color,state);
        std::string newfile(1, 'a'+(y-1));
        moveList temp(rank,file,rank+1,newfile,score);
        movelist.push_back(temp);
    }
    if(!isOccupied(x-1,y+1,color,state) && !risk[x-1][y+1] && !occState[x-1][y+1])//lower right
    {
        score = enemyOccupied(x-1,y+1,color,state);
        std::string newfile(1, 'a'+(y+1));
        moveList temp(rank,file,rank-1,newfile,score);
        movelist.push_back(temp);
    }
    if(!isOccupied(x-1,y-1,color,state) && !risk[x-1][y-1] && !occState[x-1][y-1])//lower left
    {
        score = enemyOccupied(x-1,y-1,color,state);
        std::string newfile(1, 'a'+(y-1));
        moveList temp(rank,file,rank-1,newfile,score);
        movelist.push_back(temp);
    }

    return movelist;
}

//#######################################################################################
//#######################################################################################
//this function generates the moves and calls pieceMove functions 
//essentially walks down the state until it finds a piece of given color to then generate
//its respective moves
//then return the list of moves of all friendly pieces on the grid
std::vector<moveList> AI::createMoves(const char state[8][8], std::string curColor, const bool risk[8][8], const bool occState[8][8])
{
    std::vector<moveList> movelist;
    std::vector<moveList> temp;

    char pawn = 'P',knight = 'N',bishop = 'B',queen = 'Q',king = 'K',rook = 'R';
    if(curColor == "Black")
    {
	pawn = tolower(pawn);
	knight = tolower(knight);
	bishop = tolower(bishop);
	queen = tolower(queen);
	king = tolower(king);
	rook = tolower(rook);
    }

    for(int i=0; i<8; i++)
	for(int j=0; j<8; j++)
	{
	    char piece = state[i][j];

	    if(piece == pawn)
    	    {
		temp = pawnMoves(i,j,state,curColor,risk, occState);
		movelist.insert(movelist.end(), temp.begin(), temp.end());
	    }
	    else if(piece == knight)
	    {
		temp = knightMoves(i,j,state,curColor,risk,occState);
		movelist.insert(movelist.end(), temp.begin(), temp.end());
	    }
	    else if(piece == bishop)
	    {
		temp = bishopMoves(i,j,state,curColor,risk,occState);
		movelist.insert(movelist.end(), temp.begin(), temp.end());
	    }
	    else if(piece == queen)
	    {
		temp = queenMoves(i,j,state,curColor,risk,occState);
		movelist.insert(movelist.end(), temp.begin(), temp.end());
	    }
	    else if(piece == king)
	    {
		temp = kingMoves(i,j,state,curColor,risk,occState);
		movelist.insert(movelist.end(), temp.begin(), temp.end());
	    }
	    else if(piece == rook)
	    {
		temp = rookMoves(i,j,state,curColor,risk,occState);
		movelist.insert(movelist.end(), temp.begin(), temp.end());
	    }
	}
    return movelist;
}

//#######################################################################################
//#######################################################################################
//###############################-start of risk management-##############################

//#######################################################################################
//updates the risk grid for the given bishop location

void AI::bishopRisk(bool (&risk)[8][8], const char state[8][8], int x, int y, std::string color)
{
    int dist = 1;
    bool UR = false, UL = false, LL = false, LR = false;

    //works the same as the move generator except marks places on a map
    do{
	if(!UR)
	{
	    if(x+dist < 8 && y+dist < 8)
	    {
		risk[x+dist][y+dist] = true;
		if(isOccupied(x+dist,y+dist,color,state) || enemyOccupied(x+dist,y+dist,color,state))
		    UR = true;
	    }
	    else
		UR = true;
	}
	if(!UL)
	{
            if(x+dist < 8 && y-dist >= 0)
            {
                risk[x+dist][y-dist] = true;
                if(isOccupied(x+dist,y-dist,color,state) || enemyOccupied(x+dist,y-dist,color,state))
                    UL = true;
            }
            else
                UL = true;
	}
	if(!LL)
	{
            if(x-dist >= 0 && y+dist < 8)
            {
                risk[x-dist][y+dist] = true;
                if(isOccupied(x-dist,y+dist,color,state) || enemyOccupied(x-dist,y+dist,color,state))
                    LL = true;
            }
            else
                LL = true;
	}
	if(!LR)
	{
            if(x-dist >= 0 && y-dist >= 0)
            {
                risk[x-dist][y-dist] = true;
                if(isOccupied(x-dist,y-dist,color,state) || enemyOccupied(x-dist,y-dist,color,state))
                    LR = true;
            }
            else
                LR = true;
	}

	dist++;
    }while(!UR || !UL || !LL || !LR);
    return;
}

//#######################################################################################
//updates the risk map for the rook at given location

void AI::rookRisk(bool (&risk)[8][8], const char state[8][8], int x, int y, std::string color)
{
    int dist = 1;
    bool R = false, L = false, U = false, D = false;
    //same as before but marks the risk grid instead of generating moves
    do{
	if(!R)//a->h
	{
            if(y+dist < 8)
            {
                risk[x][y+dist] = true;
                if(isOccupied(x,y+dist,color,state) || enemyOccupied(x,y+dist,color,state))
                    R = true;
            }
            else
                R = true;
	}
	if(!L)//h->a
	{
            if(y-dist >= 0)
            {
                risk[x][y-dist] = true;
                if(isOccupied(x,y-dist,color,state) || enemyOccupied(x,y-dist,color,state))
                    L = true;
            }
            else
                L = true;

	}
	if(!U)
	{
            if(x+dist < 8)
            {
                risk[x+dist][y] = true;
                if(isOccupied(x+dist,y,color,state) || enemyOccupied(x+dist,y,color,state))
                    U = true;
            }
            else
                U = true;
	}
	if(!D)
	{
            if(x-dist >= 0)
            {
                risk[x-dist][y] = true;
                if(isOccupied(x-dist,y,color,state) || enemyOccupied(x-dist,y,color,state))
                    D = true;
            }
            else
                D = true;
	}
	dist++;
    }while(!R || !L || !U || !D);

    return;
}

//#######################################################################################
//#######################################################################################
//generates the risk grid by walking through all active enemypieces then updating the 
//grid based on their possible movements 

void AI::genRisk(bool (&risk)[8][8], const char state[8][8])
{
    int rank,file;
    char temp[8][8];
   /* char teststate[8][8];
    bool testrisk[8][8];

    for(int i=0;i<8;i++)
	for(int j=0;j<8;j++)
	    teststate[i][j] = '.';

    for(int i=0;i<8;i++)
	for(int j=0;j<8;j++)
	    testrisk[i][j]=false;

    rookRisk(testrisk,teststate, 3, 3, player->opponent->color);
    bishopRisk(testrisk,teststate,3,3, player->opponent->color);
    
    for(int i=0;i<8;i++)
    {
	std::cout<<std::endl;
	for(int j=0;j<8;j++)
	    std::cout<<testrisk[i][j];
    }
*/
    for(int i=0;i<8;i++)//remove the king to better generate risk for king movement
	for(int j=0;j<8;j++)
	{
	    if(state[i][j]=='K' && player->opponent->color == "Black")
		temp[i][j] = '.';
	    else if(state[i][j]=='k' && player->opponent->color == "White")
		temp[i][j] = '.';
	    else
		temp[i][j] = state[i][j];
	}

    for(const auto& piece : player->opponent->pieces)
    {
	rank = piece->rank - 1;
	file = (int) piece->file[0] - 97;
	if(piece->type == "Pawn")
	{
	    if(player->opponent->color == "Black")
	    {
		if(rank - 1 >= 0 && file - 1 >= 0)
		   risk[rank-1][file-1] = true;
		if(rank - 1 >= 0 && file + 1 < 8)
		   risk[rank-1][file+1] = true;
	    }
	    else
	    {
		if(rank + 1 < 8 && file - 1 >=0)
		    risk[rank+1][file-1] = true;
		if(rank + 1 < 8 && file + 1 < 8)
		    risk[rank+1][file+1] = true;
	    }
	}
	else if(piece->type == "Knight")
	{
	    if(rank + 2 < 8 && file + 1 < 8)
		risk[rank+2][file+1] = true;
            if(rank + 2 < 8 && file - 1 >= 0)
                risk[rank+2][file-1] = true;
            if(rank - 2 < 8 && file + 1 < 8)
                risk[rank-2][file+1] = true;
            if(rank - 2 < 8 && file - 1 >= 0)
                risk[rank-2][file-1] = true;
            if(rank + 1 < 8 && file + 2 < 8)
                risk[rank+1][file+2] = true;
            if(rank - 1 >= 0 && file + 2 < 8)
                risk[rank-1][file+2] = true;
            if(rank + 1 < 8 && file - 2 >= 0)
                risk[rank+1][file-2] = true;
            if(rank - 1 >= 0 && file - 2 >= 0)
                risk[rank-1][file-2] = true;

	}
        //rook and bishop get functions so I don't have to repeat for queen
	else if(piece->type == "Bishop")
	{
	    bishopRisk(risk,temp,rank,file,player->opponent->color);
	}
	else if(piece->type == "Rook")
	{
	    rookRisk(risk,temp,rank,file,player->opponent->color);
	}
	else if(piece->type == "Queen")
	{
	    bishopRisk(risk,temp,rank,file,player->opponent->color);
	    rookRisk(risk,temp,rank,file,player->opponent->color);
	}
	else if(piece->type == "King")
	{
	    if(rank+1 < 8)
		risk[rank+1][file] = true;
	    if(rank-1 >= 0)
		risk[rank-1][file] = true;
	    if(file+1 < 8)
		risk[rank][file+1] = true;
	    if(file-1 >= 0)
		risk[rank][file-1] = true;
	    if(rank+1 < 8 && file+1 < 8)
		risk[rank+1][file+1] = true;
	    if(rank+1 < 8 && file-1 >= 0)
		risk[rank+1][file-1] = true;
	    if(rank-1 >=0 && file+1 < 8)
		risk[rank-1][file+1] = true;
	    if(rank-1 >=0 && file-1 >= 0)
		risk[rank-1][file-1] = true;
	}
    }

    return;
}

} // chess

} // cpp_client
