// AI
// This is where you build your AI

#include "ai.hpp"

// <<-- Creer-Merge: includes -->> - Code you add between this comment and the end comment will be preserved between Creer re-runs.
// You can add #includes here for your AI.
#include<ctime>
// <<-- /Creer-Merge: includes -->>

namespace cpp_client
{

namespace chess
{
//#######################################################################################
//#Sean Sikorski
//#ai.cpp
//#######################################################################################
//#I couldn't figure out how to get seperate files going while still maintaining access
//#to the AI and Chess structs so this and the header contain all the structs and 
//#functions to get the AI going
//#######################################################################################

//#State constructor
State::State()
{
    for(int i=0;i<8;i++)
        for(int j=0;j<8;j++)
        {
            board[i][j] = '.';
            riskState[i][j] = false;
            occupancy[i][j] = false;
        }
}

State::State(const char state[8][8], std::string color)
{
    for(int i=0;i<8;i++)
        for(int j=0;j<8;j++)
        {
            board[i][j] = state[i][j];
            riskState[i][j] = false;
            occupancy[i][j] = false;
        }
    
    //this function is not inherintly necessary but makes it easier for me to find
    //the bug mentioned later. This generates the risk and occupancy state.
    test(state,occupancy,riskState,color);

    /*So I'm getting a really weird bug where the black teams state corrupts 
    after risk. (I printBoard before and after risk). then when I try and locate 
    where it corrupts in risk (aka put some printboards inside risk at different 
    places) the board corrupts at occupancy creation. this is the only way I can
    think to fix this problem. I honestly think this is a problem with my computer
    because it comes down to the state corrupting when one of the two functions return
    not touching the state at all.*/
    for(int i=0;i<8;i++)
        for(int j=0;j<8;j++)
        {
            board[i][j] = state[i][j];
        }
}


//#moveList constructors including default, with and without parents
moveList::moveList() 
{
    rank = 10; //outlandish number to check if not initialized
}

moveList::moveList(const char board[8][8], std::string team)//very first state
{
    /*The only parts that we care about with the initial state is the board itself
        and initial team color to generate proper moves from. */
    rank = -1;
    file = "";
    moveRank = -1;
    moveFile = "";
    color = team;
    score = 0;

    char temp[8][8];
    for(int i=0; i<8; i++)
        for(int j=0; j<8; j++)
            temp[i][j] = board[i][j];

    State tempState(temp,team);

    state = tempState;
}

moveList::moveList(moveList item, int y, std::string x, int moveY, std::string moveX, int amount)
{
    /*this version contains proper move functionality. meaning they actually contain valid moves
        while also containing the ability to branch moves from.*/
    rank = y;
    file = x;
    moveRank = moveY;
    moveFile = moveX;
    score = amount;
    //this helps make sure that you are generating moves for the opposite team in minmax
    if(item.color == "White")
        color = "Black";
    else
        color = "White";
    //create the post move board which will be used to create a post move state for this move
    int tempx,tempy,tempmx,tempmy;
    tempy = rank-1;
    tempmy = moveRank-1;
    tempx = (int) file[0]-97;
    tempmx = (int) file[0]-97;
    char temp[8][8];
    for(int i=0;i<8;i++)
        for(int j=0;j<8;j++)
            temp[i][j] = item.state.board[i][j];
    temp[tempmx][tempmy] = temp[tempx][tempy];
    temp[tempx][tempy]='.';
    State tempState(temp,color);
    state = tempState;
}

//#moveList end


//#######################################################################################

/// <summary>
/// This returns your AI's name to the game server.
/// Replace the string name.
/// </summary>
/// <returns>The name of your AI.</returns>
std::string AI::get_name() const
{
    // <<-- Creer-Merge: get-name -->> - Code you add between this comment and the end comment will be preserved between Creer re-runs.
    // REPLACE WITH YOUR TEAM NAME!
    return "Sean Sikorski";
    // <<-- /Creer-Merge: get-name -->>
}

/// <summary>
/// This is automatically called when the game first starts, once the game objects are created
/// </summary>
void AI::start()
{
    // <<-- Creer-Merge: start -->> - Code you add between this comment and the end comment will be preserved between Creer re-runs.
    srand(time(NULL));//using random to pick from the moves generated

    // This is a good place to initialize any variables
    // <<-- /Creer-Merge: start -->>
}


/// <summary>
/// This is automatically called the game (or anything in it) updates
/// </summary>
void AI::game_updated()
{
    // <<-- Creer-Merge: game-updated -->> - Code you add between this comment and the end comment will be preserved between Creer re-runs.
    // If a function you call triggers an update this will be called before it returns.
    // <<-- /Creer-Merge: game-updated -->>
}

/// <summary>
/// This is automatically called when the game ends.
/// </summary>
/// <param name="won">true if you won, false otherwise</param>
/// <param name="reason">An explanation for why you either won or lost</param>
void AI::ended(bool won, const std::string& reason)
{
    //<<-- Creer-Merge: ended -->> - Code you add between this comment and the end comment will be preserved between Creer re-runs.
    // You can do any cleanup of your AI here.  The program ends when this function returns.
    //<<-- /Creer-Merge: ended -->>
}

/// <summary>
/// This is called every time it is this AI.player's turn.
/// </summary>
/// <returns>Represents if you want to end your turn. True means end your turn, False means to keep your turn going and re-call this function.</returns>
bool AI::run_turn()
{
    // <<-- Creer-Merge: runTurn -->> - Code you add between this comment and the end comment will be preserved between Creer re-runs.
    //##################################################################################
    //############################RUN TURN START########################################
    chess::Piece randPiece = nullptr;//initialized later when choosing a move to make
    //std::string getdepth = get_setting("depth_limit");
    //int depth = 3;
    int max = -1;
    int min = 20;
    double timelimit = 3;//max amount of secs to end turn. would not recommend making it much longer 
    clock_t begin = clock();
    clock_t end;
    char curState[8][8];//current state of the board

    //if(!getdepth.empty())
        //depth = atoi(getdepth.c_str());
    //if(depth <= 0)
        //depth = 3; //go back to default setting of 3 depth

    //###################################################################################
    //vvvvvvvvvvvvvvvvv-Map Initializer-#################################################
    genState(curState);
    moveList curMove(curState, player->color);
    moveList temp(curState, player->color);

    std::cout<<std::endl;
    
    //###################################################################################
    //vvvvv-pushes all possible moves unto move list-vvvvv###############################   
    curMove.children = createMoves(curMove);
    
    unsigned i = 0;
    while(i<curMove.children.size())
    {
        if(curMove.children.size() <= 0 && futureCheck(curMove.children[i].state.riskState,curMove.children[i].state.board, curMove.children[i].color))
        {
            curMove.children.erase(curMove.children.begin()+i);
            std::cout<<"triggered"<<std::endl;
        }
        else
            i++;
    }
    //###################################################################################
    //vvvvv-Move Generation-vvvvv########################################################
    int depth = 1;//starting depth for itterative deepening 
    double elapsed = 0;//time that has elapsed since previous move
    while(elapsed < timelimit)//while time elapsed is less than the time limit
    {
        temp = minimax(curMove.children, depth, max, min);//grab result of minimax
        end = clock();
        elapsed = double(end - begin) / CLOCKS_PER_SEC;
        std::cout<<elapsed<<" seconds elapsed"<<std::endl;
        depth++;
    }
    /*//print current move's intended result and risk state
    for(int i=0;i<8;i++)
    {
        std::cout<<std::endl;
        for(int j=0;j<8;j++)
            std::cout<<temp.state.board[i][j];
    }

    for(int i=0;i<8;i++)
    {
        std::cout<<std::endl;
        for(int j=0;j<8;j++)
            std::cout<<temp.state.riskState[i][j];
    }
    */
    for(const auto& piece : player->pieces)
        if(piece->file == temp.file && piece->rank == temp.rank)
        {
            randPiece = piece;
            break;
        }
    if(randPiece->type=="Pawn")
    {
        if(player->color == "White" && temp.moveRank == 8)
        {
            printMove(randPiece,temp);
            std::cout<<"Piece Promoted To Queen"<<std::endl;
            printMoves(randPiece, curMove.children);
            randPiece->move(temp.moveFile,temp.moveRank,"Queen");
        }
        else if(player->color == "Black" && temp.moveRank == 1)
        {
            printMove(randPiece,temp);
            std::cout<<"Piece Promoted To Queen"<<std::endl;
            printMoves(randPiece, curMove.children);
            randPiece->move(temp.moveFile,temp.moveRank,"Queen");
        }
        else
        {
            printMove(randPiece,temp);
            printMoves(randPiece,curMove.children);
            randPiece->move(temp.moveFile,temp.moveRank);
        }
    }
    else
    {
        printMove(randPiece,temp);
        printMoves(randPiece,curMove.children);
        randPiece->move(temp.moveFile,temp.moveRank);
    }

    return true;
    //#############################RUN TURN END##########################################
    //###################################################################################

    // Put your game logic here for run_turn here
    // <<-- /Creer-Merge: runTurn -->>
}

//<<-- Creer-Merge: methods -->> - Code you add between this comment and the end comment will be preserved between Creer re-runs.
// You can add additional methods here for your AI to call
//<<-- /Creer-Merge: methods -->>

//#######################################################################################
//generates the current state of the game (should probably go in update but it crashed
//  when I did that)

//#######################################################################################
//Junk function that prints all possible moves of the piece given
void AI::printMove(const chess::Piece piece, const moveList move)
{
    std::cout<<std::endl<<piece->owner->color<<" "<<piece->type<<" from ";
    std::cout<<move.file<<move.rank<<" to "<<move.moveFile<<move.moveRank;
    std::cout<<std::endl;
    return;
}

void AI::printMoves(const chess::Piece piece, const std::vector<moveList> movelist)
{
    std::cout<<std::endl<<"All Possible Moves Of This "<<piece->type<<"."<<std::endl;

    for(const auto& move : movelist)
        if(move.file == piece->file && move.rank == piece->rank)
        {
            std::cout<<move.file<<move.rank<<"->"<<move.moveFile<<move.moveRank<<std::endl;
        }

    return;
}
//debug function to print the board
void printBoard(const char board[8][8])
{
    for(int i=0;i<8;i++)
    {
        std::cout<<std::endl;
        for(int j=0;j<8;j++)
            std::cout<<board[i][j];
    }
}

void AI::genState(char (&state)[8][8])
{
    //initialize the grid with periods for no piece here
    for(int i=0; i<8; i++)
    {
        for(int j=0; j<8; j++)
            state[i][j] = '.'; 
    }

    //walks through all the pieces in the game and places 
    //  them on the grid in their respective locations
    for(const auto& piece : game->pieces)
    {
        int file = (int)piece->file[0] - 97;//convert file string to int from ascci
        int rank = piece->rank-1;
        char type = (char)piece->type[0];//grabs the first letter of the piece type
        if(piece->type == "Knight")//K is already used by king so knight is N
            type = 'N';
        if(piece->owner->id == "1")//if the peice is black (1) it is lowercase
            type = tolower(type);
        state[rank][file] = type;//place type letter on the grid
    }

    //DEBUG: prints the state
    for(int i=0; i<8; i++)
    {
        std::cout<<std::endl;
        for(int j=0; j<8; j++)
            std::cout<<state[i][j];
    }

    return;
}

/*MinMax with pruning, purposly pass by value so when this function is iteratively called
    min and max are reset to their psuedo inf and -inf values. this essentially takes in 
    a list of possible moves generated from the initial state to find the max of those moves*/

moveList minimax(std::vector<moveList> movelist, int depth, int max, int min)
{
    //if depth was 0 or below this function would not run
    //we already have the first nodes on the list so all that is left is searching them
    int placeHolder = -1, curMax = -1, temp;
    for(unsigned i=0;i<movelist.size();i++)
    {
        temp = findMax(movelist[i],depth-1,max,min);
        if(curMax < temp)
        {
            placeHolder = i;
            curMax = temp;
            if(curMax > max)//update max if our current max for this node is greater than previous options
                max = curMax;
        }
        //there is no need to worry about checking for fail low since there is no min call
        //   above the original minimax call
    }
    return movelist[placeHolder];
}

/*find Max will depending on the depth either return that moves score or 
    generate the next set of moves if depth allows and finds the minimum 
    score of those moves*/

int findMax(moveList move, int depth, int max, int min)
{
    if(depth <= 0)
        return move.score;
    else
    {
        int placeHolder = -1, curMin = 20, temp;
        move.children = createMoves(move);
        for(unsigned i=0;i<move.children.size();i++)
        {
            temp = findMin(move.children[i],depth-1,max,min);
            if(curMin > temp)
            {
                placeHolder = i;
                curMin = temp;
                if (curMin < min)
                    min = curMin;
            }
            //checks for fail low, if the current min is already lower than the previous nodes min
            //    standard might aswell stop searching this branch
            if(curMin < max)
                break;
        }
        return move.children[placeHolder].score;
    }
}

/*find Min will depending on the depth either return that moves score or 
    generate the next set of moves if depth allows and finds the maximum 
    score of those moves*/

int findMin(moveList move, int depth, int max, int min)
{
    if(depth <=0)
        return move.score;
    else
    {
        int placeHolder = -1, curMax = -1, temp;
        move.children = createMoves(move);
        for(unsigned i=0;i<move.children.size();i++)
        {
            temp = findMax(move.children[i],depth-1,max,min);
            if(curMax < temp)
            {
                placeHolder = i;
                curMax = temp;
                if(curMax > max)
                    max = curMax;
            }
            //checks fail high, prevents needlessly searching down a branch that might
            //    have values higher than what the min call will accept.
            if(curMax > min)
                break;
        }
        return move.children[placeHolder].score;
    }
}

//#######################################################################################
//checks if a position is occupied by a unit of the given color

bool isOccupied(int x, int y, std::string color, const char state[8][8])
{
    if(x > 7 || y > 7 || x < 0 || y < 0)//prevent walking off array
        return true;
    bool occupied = false;//if occupied initializer
    char temp = state[x][y];//reduce bulk
    //vvvv-peices that we are looking for-vvvv
    char pawn = 'P', knight = 'N', rook = 'R', bishop = 'B', queen = 'Q', king = 'K';
    if(color == "Black")//if color is black then change pieces to lowercase
    {
        pawn = tolower(pawn);
        knight = tolower(knight);
        rook = tolower(rook);
        bishop = tolower(bishop);
        queen = tolower(queen);
        king = tolower(king);
    }
    //if the current char at position [x][y] is representive of a piece then return true
    if(temp == pawn || temp == knight || temp == rook || temp == bishop || temp == queen || temp == king)
        occupied = true;
    return occupied;
}

void occupancyTest(bool (&house)[8][8], std::string color, const char state[8][8])
{
    for(int i=0;i<8;i++)
        for(int j=0;j<8;j++)
            house[i][j] = isOccupied(i, j, color, state);
    return;
}

//#######################################################################################
//checks a location for a piece of opposite color returns a score that is dependent on
//the piece found (if at all)

int enemyOccupied(int x, int y, std::string color, const char state[8][8])
{
    if(x > 7 || y > 7 || x < 0 || y < 0)//prevent walking off array
        return 0;
    int score = 0;//if 0 then not occupied
    char temp = state[x][y];//bulk reducer
    //vvvvv-pieces that we are looking for
    char pawn = 'P', knight = 'N', rook = 'R', bishop = 'B', queen = 'Q', king = 'K';
    if(color == "White")//looking for enemy team
    {
        pawn = tolower(pawn);
        knight = tolower(knight);
        rook = tolower(rook);
        bishop = tolower(bishop);
        queen = tolower(queen);
        king = tolower(king);
    }
    
    //generate score off of possible capture 
    if(temp == pawn)
        score = 1;
    else if(temp == knight)
        score = 3;
    else if(temp == bishop)
        score = 3;
    else if(temp == rook)
        score = 5;
    else if(temp == queen)
        score = 9;
    else if(temp == king)
        score = 10;

    return score;//if score is 0 then no enemy at this location
}

void test(const char board[8][8], bool (&house)[8][8], bool (&risk)[8][8], std::string color)
{
    occupancyTest(house,color,board);
    genRisk(risk,board,color);
}

//#######################################################################################
//takes a move and generates a future risk map, then checks if this move will put our 
//king in check, if it does we return true
//**********************not used as it is too harsh right now****************************
//needs reworking

bool AI::futureCheck(const bool risk[8][8], const char state[8][8], std::string color)
{
    //so this recieves post move state and risk so this should be fairly easy to check
    char king = 'K';
    bool kingPresent = false;
    bool atRisk = false;
    if(color == "Black")
        king = tolower(king);

    for(int i=0;i<8;i++)
        for(int j=0;j<8;j++)
        {
            if(state[i][j] == king)
            {
                kingPresent = true;
                if(risk[i][j] == true)
                {
                    atRisk = true;
                }
            }
        }
    if(!kingPresent)
        atRisk = true;

    return atRisk;
}

//#######################################################################################
//generates possible moves for the pawn at the given location

std::vector<moveList> pawnMoves(int x, int y, moveList curState)
{
    std::vector<moveList> movelist;
    int rank = x+1;
    std::string file(1, 'a'+y);
    bool enemyOcc[8][8];
    if(curState.color == "White")//get bool board of all enemy locations
        occupancyTest(enemyOcc, "Black", curState.state.board);
    else
        occupancyTest(enemyOcc, "White", curState.state.board);

    int capture;//carries score from any possible captures
    //probably one of the more tedious pieces because they have a specified direction 
    //they need to follow depending on color
    //moving 'forward' 1 space
    if(curState.color == "White" && !isOccupied(x+1,y,"White",curState.state.board) && !isOccupied(x+1,y,"Black",curState.state.board) && !curState.state.occupancy[x+1][y] && !enemyOcc[x+1][y])
    {
        moveList temp(curState, rank, file, rank+1, file, 0);
        movelist.push_back(temp);
    }
    else if(curState.color == "Black" && !isOccupied(x-1,y,"Black",curState.state.board) && !isOccupied(x+1,y,"White",curState.state.board) && !curState.state.occupancy[x-1][y] && !enemyOcc[x-1][y])
    {
        moveList temp(curState, rank, file, rank-1, file, 0);
        movelist.push_back(temp);
    }

    //moving diagnol in case of capture
    if(curState.color == "White")
    {
        capture = enemyOccupied(x+1,y+1,"White",curState.state.board);
        if(capture > 0)
        {
            std::string newfile(1, 'a'+(y+1));
            moveList temp(curState, rank, file, rank+1, newfile, capture);
            movelist.push_back(temp);
        }
        capture = enemyOccupied(x+1,y-1,"White",curState.state.board);
        if(capture > 0)
        {
            std::string newfile(1, 'a'+(y-1));
            moveList temp(curState, rank, file, rank+1, newfile, capture);
            movelist.push_back(temp);
        }
    }
    else if(curState.color == "Black")
    {
        capture = enemyOccupied(x-1,y+1,"Black",curState.state.board);
        if(capture > 0)
        {
            std::string newfile(1, 'a'+(y+1));
            moveList temp(curState, rank, file, rank-1, newfile, capture);
            movelist.push_back(temp);
        }
        capture = enemyOccupied(x-1,y-1,"Black",curState.state.board);
        if(capture > 0)
        {
            std::string newfile(1, 'a'+(y-1));
            moveList temp(curState, rank, file, rank-1, newfile, capture);
            movelist.push_back(temp);
        }
    }

    return movelist;//return list of moves made
}

//#######################################################################################
//generates possible moves for the knight

std::vector<moveList> knightMoves(int x, int y, moveList curState)
{
    std::vector<moveList> movelist;
    int rank = x+1;
    std::string file(1, 'a'+y);
    int score;

    //the most straight forward of the bunch, since it can jump over friendlys we only
    //need to worry about where he lands and we don't have to worry about looping 
    //::So essentially this checks all locations that the knight can move and checks if
    //  freindlys are there. If not it generates a move for the knight.
    if(!isOccupied(x+2,y+1,curState.color,curState.state.board) && !curState.state.occupancy[x+2][y+1])
    {
        std::string newfile(1, 'a'+(y+1));
        score = enemyOccupied(x+2,y+1,curState.color,curState.state.board);
        moveList temp(curState, rank, file, rank+2, newfile, score);
        movelist.push_back(temp);
    }
    
    if(!isOccupied(x+2,y-1,curState.color,curState.state.board) && !curState.state.occupancy[x+2][y-1])
    {
        std::string newfile(1, 'a'+(y-1));
        score = enemyOccupied(x+2,y-1,curState.color,curState.state.board);
        moveList temp(curState, rank, file, rank+2, newfile, score);
        movelist.push_back(temp); 
    }

    if(!isOccupied(x-2,y+1,curState.color,curState.state.board) && !curState.state.occupancy[x-2][y+1])
    {
        std::string newfile(1, 'a'+(y+1));
        score = enemyOccupied(x-2,y+1,curState.color,curState.state.board);
        moveList temp(curState, rank, file, rank-2, newfile, score);
        movelist.push_back(temp);
    }

    if(!isOccupied(x-2,y-1,curState.color,curState.state.board) && !curState.state.occupancy[x-2][y-1])
    {
        std::string newfile(1, 'a'+(y-1));
        score = enemyOccupied(x-2,y-1,curState.color,curState.state.board);
        moveList temp(curState, rank, file, rank-2, newfile, score);
        movelist.push_back(temp);
    }

    if(!isOccupied(x+1,y+2,curState.color,curState.state.board) && !curState.state.occupancy[x+1][y+2])
    {
        std::string newfile(1, 'a'+(y+2));
        score = enemyOccupied(x+1,y+2,curState.color,curState.state.board);
        moveList temp(curState, rank, file, rank+1, newfile, score);
        movelist.push_back(temp);
    }

    if(!isOccupied(x-1,y+2,curState.color,curState.state.board) && !curState.state.occupancy[x-1][y+2])
    {
        std::string newfile(1, 'a'+(y+2));
        score = enemyOccupied(x-1,y+2,curState.color,curState.state.board);
        moveList temp(curState, rank, file, rank-1, newfile, score);
        movelist.push_back(temp);
    }

    if(!isOccupied(x+1,y-2,curState.color,curState.state.board) && !curState.state.occupancy[x+1][y-2])
    {
        std::string newfile(1, 'a'+(y-2));
        score = enemyOccupied(x+1,y-2,curState.color,curState.state.board);
        moveList temp(curState, rank, file, rank+1, newfile, score);
        movelist.push_back(temp);
    }

    if(!isOccupied(x-1,y-2,curState.color,curState.state.board) && !curState.state.occupancy[x-1][y-2])
    {
        std::string newfile(1, 'a'+(y-2));
        score = enemyOccupied(x-1,y-2,curState.color,curState.state.board);
        moveList temp(curState, rank, file, rank-1, newfile, score);
        movelist.push_back(temp);
    }


    return movelist;
}

//#######################################################################################
//generates possible bishop moves 

std::vector<moveList> bishopMoves(int x, int y, moveList curState)
{
    std::vector<moveList> movelist;
    bool UL = false, UR =false, LL = false, LR = false;//direction cappers
    int dist = 1;//distance from origin
    int rank = x+1;
    std::string file(1, 'a'+y);
    int score;

    //bishop and rook rely on looping to find possible moves
    //the bishop looks in an x direction gradually making the x larger until all caps are
    //called on the x.
    //caps are called when there is a friendly blocking the way or when an enemy is 
    //blocking the way but a move is still generated on their location. 
    do{

        if(!UL)//if upperleft isn't capped
        {
            if(!isOccupied(x+dist,y-dist,curState.color,curState.state.board) && !curState.state.occupancy[x+dist][y-dist])
            {
                std::string newfile(1, 'a'+(y-dist));
                score = enemyOccupied(x+dist,y-dist,curState.color,curState.state.board);
                moveList temp(curState,rank,file,rank+dist,newfile,score);
                movelist.push_back(temp);
                if(score > 0)
                    UL = true;
            }
            else
                UL = true;
        }
        if(!UR)//if upperright isn't capped
        {
            if(!isOccupied(x+dist,y+dist,curState.color,curState.state.board) && !curState.state.occupancy[x+dist][y+dist])
            {
                std::string newfile(1, 'a'+(y+dist));
                score = enemyOccupied(x+dist,y+dist,curState.color,curState.state.board);
                moveList temp(curState,rank,file,rank+dist,newfile,score);
                movelist.push_back(temp);
                if(score > 0)
                    UR = true;
            }
            else
                UR = true;
        }
        if(!LL)//if lowerleft isn't capped
        {
            if(!isOccupied(x-dist,y-dist,curState.color,curState.state.board) && !curState.state.occupancy[x-dist][y-dist])
            {
                std::string newfile(1, 'a'+(y-dist));
                score = enemyOccupied(x-dist,y-dist,curState.color,curState.state.board);
                moveList temp(curState,rank,file,rank-dist,newfile,score);
                movelist.push_back(temp);
                if(score > 0)
                    LL = true;
            }
            else
                LL = true;
        }
        if(!LR)//if lowerright isn't capped
        {
            if(!isOccupied(x-dist,y+dist,curState.color,curState.state.board) && !curState.state.occupancy[x-dist][y+dist])
            {
                std::string newfile(1, 'a'+(y+dist));
                score = enemyOccupied(x-dist,y+dist,curState.color,curState.state.board);
                moveList temp(curState,rank,file,rank-dist,newfile,score);
                movelist.push_back(temp);
                if(score > 0)
                    LR = true;
            }
            else
                LR = true;
        }

        dist++;//increment distance
    }while(!UL || !UR || !LL || !LR);


    return movelist;
}

//#######################################################################################
//gen possible moves for the rook

std::vector<moveList> rookMoves(int x, int y, moveList curState)
{
    std::vector<moveList> movelist;
    bool L = false, R = false, U = false, D = false;//direction cappers
    int dist = 1;
    int rank = x+1;
    std::string file(1, 'a'+y);
    int score;

    //similair to bishops move generator but moves in a + instead of an x
    do{
        if(!L)//if left not capped
        {
            if(!isOccupied(x,y-dist,curState.color,curState.state.board) && !curState.state.occupancy[x][y-dist])//if spot isn't occupied by friendly
            {
                std::string newfile(1, 'a'+(y-dist));
                score = enemyOccupied(x,y-dist,curState.color,curState.state.board);//check for capture
                moveList temp(curState,rank,file,rank,newfile,score);//generate move
                movelist.push_back(temp);//add move to list
                if(score > 0)//if you also captured a piece then stop looking this way
                    L = true;
            }
            else
                L = true;
        }
        if(!R)//if right not capped
        {
            if(!isOccupied(x,y+dist,curState.color,curState.state.board) && !curState.state.occupancy[x][y+dist])
            {
                std::string newfile(1, 'a'+(y+dist));
                score = enemyOccupied(x,y+dist,curState.color,curState.state.board);
                moveList temp(curState,rank,file,rank,newfile,score);
                movelist.push_back(temp);
                if(score > 0)
                    R = true;
            }
            else
                R = true;
        }
        if(!U)//if up not capped
        {
            if(!isOccupied(x+dist,y,curState.color,curState.state.board) && !curState.state.occupancy[x+dist][y])
            {
                score = enemyOccupied(x+dist,y,curState.color,curState.state.board);
                moveList temp(curState,rank,file,rank+dist,file,score);
                movelist.push_back(temp);
                if(score > 0)
                    U = true;
            }
            else
                U = true;
        }
        if(!D)//if down not capped
        {
            if(!isOccupied(x-dist,y,curState.color,curState.state.board) && !curState.state.occupancy[x-dist][y])
            {
                score = enemyOccupied(x-dist,y,curState.color,curState.state.board);
                moveList temp(curState,rank,file,rank-dist,file,score);
                movelist.push_back(temp);
                if(score > 0)
                    D = true;
            }
            else
                D = true;
        }

        dist++;

    }while(!L || !R || !U || !D);//only when all ends have been capped can this stop

    return movelist;
}

//#######################################################################################
//generate possible moves for the queen

std::vector<moveList> queenMoves(int x, int y, moveList curState)
{
    std::vector<moveList> movelist;
    std::vector<moveList> temp;
    //essentially highjacks the rook and bishop functions since it can do both of their move sets 
    //get diagonal moves
    temp = bishopMoves(x,y,curState);
    movelist.insert(movelist.end(), temp.begin(), temp.end());
    //get vertical and horizontal moves
    temp = rookMoves(x,y,curState);
    movelist.insert(movelist.end(), temp.begin(), temp.end());
 
    return movelist;
}

//#######################################################################################
//generate possible moves for the king

std::vector<moveList> kingMoves(int x, int y, moveList curState)
{
    std::vector<moveList> movelist;
    int rank = x+1;
    std::string file(1, 'a'+y);
    int score;

    //the king is fairly tricky because he can't move into spaces that are at risk of 
    //putting him in check so we use the risk board for this
    //::essentially this searchs all directions for if they are occupied then if not 
    //  if they are at risk of putting the king in check.
    //  once both are false then we can generate a move for the king
    if(!isOccupied(x+1,y,curState.color,curState.state.board) && !curState.state.riskState[x+1][y] && !curState.state.occupancy[x+1][y])//up
    {
        score = enemyOccupied(x+1,y,curState.color,curState.state.board);
        moveList temp(curState,rank,file,rank+1,file,score);
        movelist.push_back(temp);
    }
    if(!isOccupied(x-1,y,curState.color,curState.state.board) && !curState.state.riskState[x-1][y] && !curState.state.occupancy[x-1][y])//down
    {
        score = enemyOccupied(x-1,y,curState.color,curState.state.board);
        moveList temp(curState,rank,file,rank-1,file,score);
        movelist.push_back(temp);
    }
    if(!isOccupied(x,y+1,curState.color,curState.state.board) && !curState.state.riskState[x][y+1] && !curState.state.occupancy[x][y+1])//right
    {
        score = enemyOccupied(x,y+1,curState.color,curState.state.board);
        std::string newfile(1, 'a'+(y+1));
        moveList temp(curState,rank,file,rank,newfile,score);
        movelist.push_back(temp);
    }
    if(!isOccupied(x,y-1,curState.color,curState.state.board) && !curState.state.riskState[x][y-1] && !curState.state.occupancy[x][y-1])//left
    {
        score = enemyOccupied(x,y-1,curState.color,curState.state.board);
        std::string newfile(1, 'a'+(y-1));
        moveList temp(curState,rank,file,rank,newfile,score);
        movelist.push_back(temp);
    }
    if(!isOccupied(x+1,y+1,curState.color,curState.state.board) && !curState.state.occupancy[x+1][y+1] && !curState.state.occupancy[x+1][y+1])//upper right
    {
        score = enemyOccupied(x+1,y+1,curState.color,curState.state.board);
        std::string newfile(1, 'a'+(y+1));
        moveList temp(curState,rank,file,rank+1,newfile,score);
        movelist.push_back(temp);
    }
    if(!isOccupied(x+1,y-1,curState.color,curState.state.board) && !curState.state.riskState[x+1][y-1] && !curState.state.occupancy[x+1][y-1])//upper left
    {
        score = enemyOccupied(x,y-1,curState.color,curState.state.board);
        std::string newfile(1, 'a'+(y-1));
        moveList temp(curState,rank,file,rank+1,newfile,score);
        movelist.push_back(temp);
    }
    if(!isOccupied(x-1,y+1,curState.color,curState.state.board) && !curState.state.riskState[x-1][y+1] && !curState.state.occupancy[x-1][y+1])//lower right
    {
        score = enemyOccupied(x-1,y+1,curState.color,curState.state.board);
        std::string newfile(1, 'a'+(y+1));
        moveList temp(curState,rank,file,rank-1,newfile,score);
        movelist.push_back(temp);
    }
    if(!isOccupied(x-1,y-1,curState.color,curState.state.board) && !curState.state.riskState[x-1][y-1] && !curState.state.occupancy[x-1][y-1])//lower left
    {
        score = enemyOccupied(x-1,y-1,curState.color,curState.state.board);
        std::string newfile(1, 'a'+(y-1));
        moveList temp(curState,rank,file,rank-1,newfile,score);
        movelist.push_back(temp);
    }

    return movelist;
}

//#######################################################################################
//#######################################################################################
//this function generates the moves and calls pieceMove functions 
//essentially walks down the state until it finds a piece of given color to then generate
//its respective moves
//then return the list of moves of all friendly pieces on the grid
std::vector<moveList> createMoves(moveList curState)
{
    std::vector<moveList> movelist;
    std::vector<moveList> temp;

    char pawn = 'P',knight = 'N',bishop = 'B',queen = 'Q',king = 'K',rook = 'R';
    if(curState.color == "Black")
    {
        pawn = tolower(pawn);
        knight = tolower(knight);
        bishop = tolower(bishop);
        queen = tolower(queen);
        king = tolower(king);
        rook = tolower(rook);
    }

    //std::cout<<"pre move board"<<std::endl;
    //printBoard(curState.state.board);

    for(int i=0; i<8; i++)
        for(int j=0; j<8; j++)
        {
            char piece = curState.state.board[i][j];
            //char piece = state[i][j];

            if(piece == pawn)
            {
                temp = pawnMoves(i,j,curState);
                movelist.insert(movelist.end(), temp.begin(), temp.end());
            }

            else if(piece == knight)
            {
                temp = knightMoves(i,j,curState);
                movelist.insert(movelist.end(), temp.begin(), temp.end());
            }
            else if(piece == bishop)
            {
                temp = bishopMoves(i,j,curState);
                movelist.insert(movelist.end(), temp.begin(), temp.end());
            }
            else if(piece == queen)
            {
                temp = queenMoves(i,j,curState);
                movelist.insert(movelist.end(), temp.begin(), temp.end());
            }
            else if(piece == king)
            {
                temp = kingMoves(i,j,curState);
                movelist.insert(movelist.end(), temp.begin(), temp.end());
            }
            else if(piece == rook)
            {
                temp = rookMoves(i,j,curState);
                movelist.insert(movelist.end(), temp.begin(), temp.end());
            }
        }
    return movelist;
}

//#######################################################################################
//#######################################################################################
//###############################-start of risk management-##############################

//#######################################################################################
//updates the risk grid for the given bishop location

void bishopRisk(bool (&risk)[8][8], const char state[8][8], int x, int y, std::string color)
{
    int dist = 1;
    bool UR = false, UL = false, LL = false, LR = false;

    //works the same as the move generator except marks places on a map
    do{
        if(!UR)
        {
            if(x+dist < 8 && y+dist < 8)
            {
                risk[x+dist][y+dist] = true;
                if(isOccupied(x+dist,y+dist,color,state) || enemyOccupied(x+dist,y+dist,color,state))
                    UR = true;
            }
            else
                UR = true;
        }
        if(!UL)
        {
            if(x+dist < 8 && y-dist >= 0)
            {
                risk[x+dist][y-dist] = true;
                if(isOccupied(x+dist,y-dist,color,state) || enemyOccupied(x+dist,y-dist,color,state))
                    UL = true;
            }
            else
                UL = true;
        }
        if(!LL)
        {
            if(x-dist >= 0 && y+dist < 8)
            {
                risk[x-dist][y+dist] = true;
                if(isOccupied(x-dist,y+dist,color,state) || enemyOccupied(x-dist,y+dist,color,state))
                    LL = true;
            }
            else
                LL = true;
        }
        if(!LR)
        {
            if(x-dist >= 0 && y-dist >= 0)
            {
                risk[x-dist][y-dist] = true;
                if(isOccupied(x-dist,y-dist,color,state) || enemyOccupied(x-dist,y-dist,color,state))
                    LR = true;
            }
            else
                LR = true;
        }

        dist++;
    }while(!UR || !UL || !LL || !LR);
    return;
}

//#######################################################################################
//updates the risk map for the rook at given location

void rookRisk(bool (&risk)[8][8], const char state[8][8], int x, int y, std::string color)
{
    int dist = 1;
    bool R = false, L = false, U = false, D = false;
    //same as before but marks the risk grid instead of generating moves
    do{
        if(!R)//a->h
        {
            if(y+dist < 8)
            {
                risk[x][y+dist] = true;
                if(isOccupied(x,y+dist,color,state) || enemyOccupied(x,y+dist,color,state))
                    R = true;
            }
            else
                R = true;
        }
        if(!L)//h->a
        {
            if(y-dist >= 0)
            {
                risk[x][y-dist] = true;
                if(isOccupied(x,y-dist,color,state) || enemyOccupied(x,y-dist,color,state))
                    L = true;
            }
            else
                L = true;

        }
        if(!U)
        {
            if(x+dist < 8)
            {
                risk[x+dist][y] = true;
                if(isOccupied(x+dist,y,color,state) || enemyOccupied(x+dist,y,color,state))
                    U = true;
            }
            else
                U = true;
        }
        if(!D)
        {
            if(x-dist >= 0)
            {
                risk[x-dist][y] = true;
                if(isOccupied(x-dist,y,color,state) || enemyOccupied(x-dist,y,color,state))
                    D = true;
            }
            else
                D = true;
        }
        dist++;
    }while(!R || !L || !U || !D);

    return;
}

//#######################################################################################
//#######################################################################################
//generates the risk grid by walking through all active enemypieces then updating the 
//grid based on their possible movements 

void genRisk(bool (&risk)[8][8], const char state[8][8], std::string color)
{
    char temp[8][8];

    for(int i=0;i<8;i++)//remove the king to better generate risk for king movement
        for(int j=0;j<8;j++)
        {
            if(state[i][j]=='K' && color == "White")
                temp[i][j] = '.';
            else if(state[i][j]=='k' && color == "Black")
                temp[i][j] = '.';
            else
                temp[i][j] = state[i][j];
        }


    char pawn = 'P',knight = 'N',bishop = 'B',queen = 'Q',king = 'K',rook = 'R';
    if(color == "White")//we are looking for the opponents pieces
    {
        pawn = tolower(pawn);
        knight = tolower(knight);
        bishop = tolower(bishop);
        queen = tolower(queen);
        king = tolower(king);
        rook = tolower(rook);
    }

    for(int i=0; i<8; i++)
        for(int j=0; j<8; j++)
        {
            char piece = temp[i][j];

            if(piece == pawn)
            {
                if(color == "White")
                {
                if(i - 1 >= 0 && j - 1 >= 0)
                    risk[i-1][j-1] = true;
                if(i - 1 >= 0 && j + 1 < 8)
                    risk[i-1][j+1] = true;
                }
                else
                {
                if(i + 1 < 8 && j - 1 >=0)
                    risk[i+1][j-1] = true;
                if(i + 1 < 8 && j + 1 < 8)
                    risk[i+1][j+1] = true;
                }
            }
            else if(piece == knight)
            {
                if(i + 2 < 8 && j + 1 < 8)
                    risk[i+2][j+1] = true;
                if(i + 2 < 8 && j - 1 >= 0)
                    risk[i+2][j-1] = true;
                if(i - 2 < 8 && j + 1 < 8)
                    risk[i-2][j+1] = true;
                if(i - 2 < 8 && j - 1 >= 0)
                    risk[i-2][j-1] = true;
                if(i + 1 < 8 && j + 2 < 8)
                    risk[i+1][j+2] = true;
                if(i - 1 >= 0 && j + 2 < 8)
                    risk[i-1][j+2] = true;
                if(i + 1 < 8 && j - 2 >= 0)
                    risk[i+1][j-2] = true;
                if(i - 1 >= 0 && j - 2 >= 0)
                    risk[i-1][j-2] = true;
            }
            else if(piece == bishop)
            {
                bishopRisk(risk,temp,i,j,color);
            }
            else if(piece == rook)
            {
                rookRisk(risk,temp,i,j,color);
            }
            else if(piece == queen)
            {
                bishopRisk(risk,temp,i,j,color);
                rookRisk(risk,temp,i,j,color);
            }
            else if(piece == king)
            {
                if(i+1 < 8)
                    risk[i+1][j] = true;
                if(i-1 >= 0)
                    risk[i-1][j] = true;
                if(j+1 < 8)
                    risk[i][j+1] = true;
                if(j-1 >= 0)
                    risk[i][j-1] = true;
                if(i+1 < 8 && j+1 < 8)
                    risk[i+1][j+1] = true;
                if(i+1 < 8 && j-1 >= 0)
                    risk[i+1][j-1] = true;
                if(i-1 >=0 && j+1 < 8)
                    risk[i-1][j+1] = true;
                if(i-1 >=0 && j-1 >= 0)
                    risk[i-1][j-1] = true;
            }
        }

    return;
}

} // chess

} // cpp_client
